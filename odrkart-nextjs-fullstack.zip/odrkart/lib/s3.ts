// lib/s3.ts  –  SERVER SIDE ONLY
// Handles presigned URLs for client-side direct uploads, and
// server-side operations (delete, copy, get metadata).

import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

const REGION = process.env.AWS_REGION!
const BUCKET = process.env.AWS_S3_BUCKET_NAME!
const CDN_URL = process.env.AWS_CLOUDFRONT_URL || process.env.AWS_S3_BUCKET_URL

export const s3 = new S3Client({
  region: REGION,
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
})

// ── Allowed MIME types for evidence upload ────────────────────────────────────
export const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'image/jpeg',
  'image/png',
  'image/webp',
  'video/mp4',
]

export const MAX_FILE_SIZE_BYTES = 52_428_800  // 50 MB

// ── S3 key convention ─────────────────────────────────────────────────────────
// cases/{caseId}/evidence/{filename}
// cases/{caseId}/reports/{reportType}.pdf
// hearings/{hearingId}/recording.mp4
export function buildS3Key(type: 'evidence' | 'report' | 'recording', caseId: string, filename: string) {
  return type === 'evidence'  ? `cases/${caseId}/evidence/${filename}`
       : type === 'report'    ? `cases/${caseId}/reports/${filename}`
       : `hearings/${caseId}/recording.mp4`
}

// ── Generate presigned PUT URL (client uploads directly to S3) ────────────────
export async function getPresignedUploadUrl(
  s3Key: string,
  mimeType: string,
  expiresIn = 300  // 5 minutes
): Promise<string> {
  if (!ALLOWED_MIME_TYPES.includes(mimeType)) throw new Error('File type not allowed')
  const command = new PutObjectCommand({
    Bucket:      BUCKET,
    Key:         s3Key,
    ContentType: mimeType,
    ServerSideEncryption: 'AES256',
    Metadata: { uploaded: new Date().toISOString() },
  })
  return getSignedUrl(s3, command, { expiresIn })
}

// ── Generate presigned GET URL (private evidence access) ──────────────────────
export async function getPresignedDownloadUrl(s3Key: string, expiresIn = 3600): Promise<string> {
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: s3Key })
  return getSignedUrl(s3, command, { expiresIn })
}

// ── Public CDN URL (for non-sensitive assets) ─────────────────────────────────
export function getPublicUrl(s3Key: string): string {
  return `${CDN_URL}/${s3Key}`
}

// ── Delete a file ─────────────────────────────────────────────────────────────
export async function deleteS3Object(s3Key: string): Promise<void> {
  await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: s3Key }))
}

// ── Check if object exists ────────────────────────────────────────────────────
export async function s3ObjectExists(s3Key: string): Promise<boolean> {
  try {
    await s3.send(new HeadObjectCommand({ Bucket: BUCKET, Key: s3Key }))
    return true
  } catch { return false }
}
