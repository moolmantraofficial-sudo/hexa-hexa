// lib/agora.ts  –  SERVER SIDE ONLY
// Generates Agora RTC tokens for secure video hearings.
// Token expires after 1 hour (aligned with typical hearing length).

import { RtcTokenBuilder, RtcRole } from 'agora-access-token'

const APP_ID   = process.env.NEXT_PUBLIC_AGORA_APP_ID!
const APP_CERT = process.env.AGORA_APP_CERTIFICATE!

export type AgoraRole = 'host' | 'audience'

export interface AgoraTokenPayload {
  token:       string
  channel:     string
  uid:         number
  appId:       string
  expireAt:    number
}

// ── Generate a short-lived RTC token ─────────────────────────────────────────
export function generateAgoraToken(
  channelName: string,
  uid: number,
  role: AgoraRole = 'host',
  expirationSecs = 3600
): AgoraTokenPayload {
  const expireAt  = Math.floor(Date.now() / 1000) + expirationSecs
  const agoraRole = role === 'host' ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER

  const token = RtcTokenBuilder.buildTokenWithUid(
    APP_ID,
    APP_CERT,
    channelName,
    uid,
    agoraRole,
    expireAt
  )

  return { token, channel: channelName, uid, appId: APP_ID, expireAt }
}

// ── Build a deterministic channel name for a hearing ─────────────────────────
// Format: hearing_{hearingId_first8chars}
export function buildChannelName(hearingId: string): string {
  return `hearing_${hearingId.replace(/-/g, '').slice(0, 12)}`
}

// ── Assign deterministic UIDs (avoids collisions in a hearing) ────────────────
// Claimant = 1000, Respondent = 2000, Panelist = 3000, Observer = 4001+
export function roleToUid(role: 'claimant' | 'respondent' | 'panelist' | 'observer', index = 0) {
  const base = { claimant: 1000, respondent: 2000, panelist: 3000, observer: 4001 }
  return base[role] + index
}
