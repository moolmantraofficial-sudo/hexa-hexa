// lib/supabase.ts
// Exports two clients:
//   supabase        → browser client (uses anon key, respects RLS)
//   supabaseAdmin   → server-only client (uses service role key, bypasses RLS)

import { createBrowserClient, createServerClient, type CookieOptions } from '@supabase/auth-helpers-nextjs'
import { createClient } from '@supabase/supabase-js'
import { cookies } from 'next/headers'
import type { Database } from '@/types/database'

const supabaseUrl  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabaseServiceRole = process.env.SUPABASE_SERVICE_ROLE_KEY!

// ── Browser client (safe to use in Client Components) ─────────────────────────
export function createBrowserSupabase() {
  return createBrowserClient<Database>(supabaseUrl, supabaseAnon)
}

// ── Server component client (reads cookies for auth) ──────────────────────────
export function createServerSupabase() {
  const cookieStore = cookies()
  return createServerClient<Database>(supabaseUrl, supabaseAnon, {
    cookies: {
      get(name: string)                           { return cookieStore.get(name)?.value },
      set(name: string, value: string, options: CookieOptions) { try { cookieStore.set({ name, value, ...options }) } catch {} },
      remove(name: string, options: CookieOptions)             { try { cookieStore.set({ name, value: '', ...options }) } catch {} },
    },
  })
}

// ── Admin client (SERVER ONLY – bypasses RLS) ─────────────────────────────────
// Never instantiate on the client side.
export const supabaseAdmin = createClient<Database>(supabaseUrl, supabaseServiceRole, {
  auth: { autoRefreshToken: false, persistSession: false },
})
