// lib/claude.ts  –  SERVER SIDE ONLY
// All Claude API calls go through this module.
// NEVER import this in Client Components – it would expose the API key.

import Anthropic from '@anthropic-ai/sdk'

export const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

export const MODEL = 'claude-sonnet-4-20250514'
export const MAX_TOKENS = 1200

// ── Types ─────────────────────────────────────────────────────────────────────
export interface CaseContext {
  title:       string
  category:    string
  amount:      string
  resolution:  string
  description: string
  claimant:    string
  respondent:  string
  documents:   string
  date:        string
}

// ── Generate company (internal) case report ───────────────────────────────────
export async function generateCompanyReport(ctx: CaseContext): Promise<string> {
  const msg = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: MAX_TOKENS,
    messages: [{
      role: 'user',
      content: `You are a senior legal analyst at ODRkart India. Analyse this case and write a CONFIDENTIAL INTERNAL REPORT.

Case Details:
- Title: ${ctx.title}
- Category: ${ctx.category}
- Claim Amount: ₹${ctx.amount}
- Resolution Mode: ${ctx.resolution}
- Claimant: ${ctx.claimant}
- Respondent: ${ctx.respondent}
- Description: ${ctx.description}
- Documents Uploaded: ${ctx.documents}
- Filing Date: ${ctx.date}

Write a structured report with EXACTLY these section headers (plain text, no markdown, no asterisks):

CASE OVERVIEW
LEGAL MERIT ASSESSMENT
RISK ANALYSIS
PANELIST RECOMMENDATION
RESOLUTION TIMELINE
INTERNAL NOTES

Each section: 3–5 sentences. Be precise and professional.`
    }],
  })
  return msg.content.filter(b => b.type === 'text').map(b => (b as { type: 'text', text: string }).text).join('')
}

// ── Generate client-facing case summary ───────────────────────────────────────
export async function generateClientReport(ctx: CaseContext): Promise<string> {
  const msg = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: MAX_TOKENS,
    messages: [{
      role: 'user',
      content: `You are a friendly legal advisor at ODRkart India. Write a CLIENT SUMMARY for ${ctx.claimant}.

Case:
- Title: ${ctx.title}
- Category: ${ctx.category}
- Amount: ₹${ctx.amount}
- Resolution Mode: ${ctx.resolution}
- Other Party: ${ctx.respondent}
- Description: ${ctx.description}
- Documents: ${ctx.documents}
- Date: ${ctx.date}

Write with EXACTLY these section headers (plain text, no markdown, no asterisks):

CASE SUMMARY
YOUR LEGAL POSITION
WHAT HAPPENS NEXT
DOCUMENTS CHECKLIST REVIEW
TIPS FOR A STRONG CASE
ESTIMATED OUTCOME

Each section: 3–5 sentences. Use warm, supportive, plain-English tone.`
    }],
  })
  return msg.content.filter(b => b.type === 'text').map(b => (b as { type: 'text', text: string }).text).join('')
}

// ── AI Lab: generate blog post batch ─────────────────────────────────────────
export async function generateBlogPosts(
  topics: string[],
  count: number
): Promise<BlogPost[]> {
  const msg = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: MAX_TOKENS,
    messages: [{
      role: 'user',
      content: `You are ODRkart's expert AI Legal Journalist. Write exactly ${count} short blog post entries about these topics for ODRkart's AI Lab Blog (India's ODR platform):

${topics.slice(0, count).map((t, i) => `${i + 1}. ${t}`).join('\n')}

Respond ONLY with valid JSON (no markdown, no backticks):
{"posts":[{"title":"...","excerpt":"2-3 sentence compelling excerpt","category":"one of: Arbitration, Legal Tech, Consumer, International, ODR Insights","readTime":"X min read","author":"ODRkart AI Lab","emoji":"single relevant emoji"}]}`
    }],
  })
  const raw = msg.content.filter(b => b.type === 'text').map(b => (b as { type: 'text', text: string }).text).join('')
  const clean = raw.replace(/```json|```/g, '').trim()
  return JSON.parse(clean).posts as BlogPost[]
}

// ── AI Platform Summary (for AI pill panel) ───────────────────────────────────
export async function generatePlatformSummary(): Promise<string> {
  const msg = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: 900,
    messages: [{
      role: 'user',
      content: `ODRkart (est.2018): India's ODR platform. Stats: 12K+ cases, ₹240Cr, 500+ panelists, 30d avg, 80% cheaper, blockchain, ISO 27001, 98% satisfaction. New: AI Lab Blog auto-generates legal articles. AI Document Analyser creates dual reports.

Write 4 labeled sections (plain text, no markdown):
SECTION 1 — PLATFORM OVERVIEW
SECTION 2 — KEY STRENGTHS
SECTION 3 — WHO IT'S FOR
SECTION 4 — AI VERDICT`
    }],
  })
  return msg.content.filter(b => b.type === 'text').map(b => (b as { type: 'text', text: string }).text).join('')
}

// ── Shared types ─────────────────────────────────────────────────────────────
export interface BlogPost {
  title:    string
  excerpt:  string
  category: string
  readTime: string
  author:   string
  emoji:    string
}
