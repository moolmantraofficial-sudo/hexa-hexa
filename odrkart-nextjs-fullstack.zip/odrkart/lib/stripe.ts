// lib/stripe.ts  –  SERVER SIDE ONLY

import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
  typescript: true,
})

// ── Filing fee config ─────────────────────────────────────────────────────────
export const FILING_FEE_INR = 199900  // ₹1,999 in paise

// ── Create a PaymentIntent for case filing ────────────────────────────────────
export async function createCaseFilingIntent(
  caseId: string,
  caseTitle: string,
  customerEmail: string
): Promise<Stripe.PaymentIntent> {
  return stripe.paymentIntents.create({
    amount:   FILING_FEE_INR,
    currency: 'inr',
    metadata: { caseId, source: 'odrkart_filing' },
    description: `ODRkart Filing Fee – ${caseTitle}`,
    receipt_email: customerEmail,
    automatic_payment_methods: { enabled: true },
  })
}

// ── Verify Stripe webhook signature ──────────────────────────────────────────
export function constructWebhookEvent(body: Buffer, sig: string): Stripe.Event {
  return stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
}

// ── Payment status helpers ────────────────────────────────────────────────────
export function isPaymentSucceeded(intent: Stripe.PaymentIntent): boolean {
  return intent.status === 'succeeded'
}

// ── Refund a filing fee ───────────────────────────────────────────────────────
export async function refundFilingFee(paymentIntentId: string, reason?: string): Promise<Stripe.Refund> {
  return stripe.refunds.create({
    payment_intent: paymentIntentId,
    reason: 'requested_by_customer',
    metadata: { reason: reason ?? 'Case withdrawn' },
  })
}
