// components/ChatBot/ChatBot.tsx
'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Send, Bot, Zap } from 'lucide-react'
import Link from 'next/link'

interface Message {
  id:   string
  role: 'bot' | 'user'
  text: string
}

// Local KB for instant replies (no API needed for common Q&A)
const KB: Record<string, string> = {
  file:     "Click **'File a Case'** in the nav or use the button on the homepage. The 6-step wizard takes under 5 minutes!",
  service:  "We offer:\n\n⚖️ Arbitration · 🤝 Mediation\n📋 Legal Consultation · 📁 E-Filing\n🏢 Corporate ODR · 🌐 Cross-Border\n🤖 AI Document Analyser",
  fees:     "Filing: ₹999–₹4,999\nMediation from ₹2,999\nArbitration from ₹5,999\nConsultation: ₹499/session\n\nAll fees transparent before proceeding.",
  'ai blog':"Our **AI Lab Blog** auto-publishes articles using Claude AI! Scroll to the 🧠 AI Lab section and click **'Generate New Posts'** for fresh content.",
  human:    "📞 **+91 98765 43210**\n📧 support@odrkart.com\nMon–Sat 9 AM – 7 PM IST",
  arbitration: "Online arbitration awards are **legally binding** under the Arbitration & Conciliation Act 1996. Cases typically resolve in 30–60 days.",
  mediation: "Mediation is a voluntary, confidential process where a neutral mediator helps both parties reach a settlement. Usually resolves in 7–14 days.",
  secure:   "Yes! AES-256 encryption, TLS 1.3, blockchain-based audit trails, ISO 27001 certified and DPDPA 2023 compliant.",
}

const QUICK_REPLIES = ['📝 File a Case', '🛠 Services', '💰 Fees', '🧠 AI Blog']

function getLocalReply(msg: string): string | null {
  const low = msg.toLowerCase()
  const key = Object.keys(KB).find(k => low.includes(k))
  return key ? KB[key] : null
}

const INITIAL_MESSAGES: Message[] = [
  { id: '1', role: 'bot', text: '👋 Hi! Welcome to **ODRkart**.' },
  { id: '2', role: 'bot', text: 'How can I help? File a case, explore services, or check out our new **AI Lab Blog**!' },
]

export default function ChatBot() {
  const [open,       setOpen]       = useState(false)
  const [messages,   setMessages]   = useState<Message[]>(INITIAL_MESSAGES)
  const [input,      setInput]      = useState('')
  const [typing,     setTyping]     = useState(false)
  const [showQuick,  setShowQuick]  = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, typing])

  const addMsg = (text: string, role: 'bot' | 'user') => {
    setMessages(m => [...m, { id: Date.now().toString(), role, text }])
  }

  const sendMessage = async (text: string) => {
    if (!text.trim()) return
    setInput('')
    setShowQuick(false)
    addMsg(text, 'user')
    setTyping(true)

    // Check local KB first (instant)
    const local = getLocalReply(text)
    if (local) {
      setTimeout(() => { setTyping(false); addMsg(local, 'bot'); setShowQuick(true) }, 900)
      return
    }

    // Default fallback
    setTimeout(() => {
      setTyping(false)
      addMsg("I can help with:\n\n• File a case · Services · Fees\n• AI Lab Blog · Legal info\n\nCall: **+91 98765 43210**", 'bot')
      setShowQuick(true)
    }, 1200)
  }

  const handleQuickReply = (text: string) => {
    const clean = text.replace(/[📝🛠💰🧠]\s*/, '')
    sendMessage(clean)
  }

  const formatText = (text: string) =>
    text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>')

  return (
    <>
      {/* Toggle button */}
      <motion.button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-7 right-6 z-50 w-14 h-14 rounded-full bg-gradient-to-br from-pink to-purple text-white flex items-center justify-center shadow-[0_5px_18px_rgba(222,24,199,0.4)] hover:scale-110 transition-transform border-none"
        whileTap={{ scale: 0.92 }}
        aria-label="Open chat"
      >
        <AnimatePresence mode="wait">
          {open
            ? <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}><X size={22} /></motion.span>
            : <motion.span key="bot" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}><Bot size={22} /></motion.span>
          }
        </AnimatePresence>
      </motion.button>

      {/* WhatsApp button above chat toggle */}
      <a
        href="https://wa.me/919876543210"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-24 right-6 z-50 w-12 h-12 rounded-full bg-[#25d366] flex items-center justify-center shadow-[0_4px_14px_rgba(37,211,102,0.4)] hover:scale-110 transition-transform"
      >
        <svg viewBox="0 0 32 32" width="22" height="22" fill="#fff">
          <path d="M16 3C9.4 3 4 8.4 4 15c0 2.4.8 4.6 2.2 6.3L4 29l7.9-2.2A12 12 0 0 0 16 27c6.6 0 12-5.4 12-12S22.6 3 16 3zm0 21.8a9.7 9.7 0 0 1-4.9-1.4l-.4-.2-4.7 1.3 1.2-4.6-.2-.4A9.7 9.7 0 0 1 6.2 15c0-5.4 4.4-9.8 9.8-9.8 5.4 0 9.8 4.4 9.8 9.8 0 5.4-4.4 9.8-9.8 9.8zm5.3-7.3c-.3-.1-1.7-.9-2-.9-.3-.1-.5-.1-.7.1-.2.3-.7.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.5-2.4-1.5-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6.1-.1.3-.3.4-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.1-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4 0 1.4 1 2.8 1.2 3 .1.2 2 3.2 5 4.4.7.3 1.2.5 1.7.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.2-1.4 0-.2-.3-.2-.6-.4z"/>
        </svg>
      </a>

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-24 right-6 z-50 w-[350px] h-[490px] bg-white rounded-2xl shadow-[0_18px_55px_rgba(0,0,0,0.18)] flex flex-col overflow-hidden border border-gray-100"
            style={{ maxWidth: 'calc(100vw - 24px)' }}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-pink to-purple px-5 py-4 flex items-center gap-3 flex-shrink-0">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-xl flex-shrink-0">🤖</div>
              <div className="flex-1">
                <h4 className="text-white font-bold text-sm">ODRkart Assistant</h4>
                <p className="text-white/75 text-xs flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2ecc71] animate-pulse-dot" /> Online
                </p>
              </div>
              <button onClick={() => setOpen(false)} className="text-white/70 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[82%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-br from-pink to-purple text-white rounded-br-sm'
                        : 'bg-white text-gray-700 shadow-[0_2px_8px_rgba(0,0,0,0.08)] rounded-bl-sm'
                    }`}
                    dangerouslySetInnerHTML={{ __html: formatText(msg.text) }}
                  />
                </div>
              ))}

              {/* Typing indicator */}
              {typing && (
                <div className="flex justify-start">
                  <div className="bg-white rounded-2xl rounded-bl-sm px-4 py-3 shadow-[0_2px_8px_rgba(0,0,0,0.08)] flex gap-1">
                    {[0,1,2].map(i => (
                      <span key={i} className="w-2 h-2 bg-gray-300 rounded-full animate-bounce-dots" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick replies */}
            <AnimatePresence>
              {showQuick && !typing && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="flex gap-2 px-3 py-2 bg-gray-50 flex-wrap overflow-hidden"
                >
                  {QUICK_REPLIES.map(q => (
                    <button
                      key={q}
                      onClick={() => handleQuickReply(q)}
                      className="bg-white border-2 border-pink text-pink px-3 py-1.5 rounded-full text-xs font-semibold hover:bg-pink hover:text-white transition-all"
                    >
                      {q}
                    </button>
                  ))}
                  <Link
                    href="/file"
                    onClick={() => setOpen(false)}
                    className="bg-pink text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 hover:shadow-pink transition-all"
                  >
                    <Zap size={10} /> File Case
                  </Link>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Input */}
            <div className="flex gap-2 p-3 bg-white border-t border-gray-100">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage(input)}
                placeholder="Type your message…"
                className="flex-1 border-2 border-gray-100 rounded-full px-4 py-2 text-sm outline-none transition-all focus:border-pink font-sans"
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || typing}
                className="w-9 h-9 rounded-full bg-gradient-to-br from-pink to-purple text-white flex items-center justify-center hover:scale-110 transition-transform disabled:opacity-40 flex-shrink-0"
              >
                <Send size={14} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
