// components/ui/Navbar.tsx
'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter, usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, ChevronDown, LogOut, User } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'

const NAV_LINKS = [
  { label: 'Home',        href: '/#home' },
  { label: 'About',       href: '/#about' },
  { label: 'Services',    href: '/#services' },
  { label: 'Expert Panel',href: '/#judges' },
  { label: 'AI Lab Blog', href: '/#ailab' },
  { label: 'Contact',     href: '/#contact' },
]

export default function Navbar() {
  const { user, loading, signOut } = useAuth()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrolled,   setScrolled]   = useState(false)
  const [userMenu,   setUserMenu]   = useState(false)
  const router    = useRouter()
  const pathname  = usePathname()

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handler, { passive: true })
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const handleSignOut = async () => {
    await signOut()
    router.push('/')
  }

  return (
    <>
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/97 backdrop-blur-xl shadow-[0_2px_20px_rgba(222,24,199,0.12)]' : 'bg-white/95 backdrop-blur-lg'
      }`}>
        <nav className="max-w-[1280px] mx-auto px-10 h-16 flex items-center justify-between gap-6">
          {/* Logo */}
          <Link href="/" className="text-[1.75rem] font-black text-pink flex-shrink-0 leading-none">
            ODR<span className="text-dark">kart</span>
          </Link>

          {/* Desktop links */}
          <ul className="hidden lg:flex gap-6 list-none flex-1 justify-center">
            {NAV_LINKS.map(link => (
              <li key={link.label}>
                <Link
                  href={link.href}
                  className="text-gray-500 font-medium text-sm hover:text-pink transition-colors relative group"
                >
                  {link.label}
                  <span className="absolute -bottom-0.5 left-0 w-0 h-0.5 bg-pink rounded-full transition-all group-hover:w-full" />
                </Link>
              </li>
            ))}
          </ul>

          {/* Auth buttons */}
          <div className="hidden lg:flex items-center gap-3 flex-shrink-0">
            {loading ? (
              <div className="w-8 h-8 rounded-full border-2 border-pink/20 border-t-pink animate-spin" />
            ) : user ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenu(m => !m)}
                  className="flex items-center gap-2 border-2 border-pink text-pink px-4 py-2 rounded-full font-semibold text-sm hover:bg-pink hover:text-white transition-all"
                >
                  <User size={14} /> {user.email?.split('@')[0]}
                  <ChevronDown size={14} className={`transition-transform ${userMenu ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {userMenu && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                      className="absolute right-0 top-full mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50"
                    >
                      <Link href="/dashboard" className="flex items-center gap-2 px-4 py-3 text-sm text-gray-700 hover:bg-pink/5 hover:text-pink transition-colors">
                        📋 My Cases
                      </Link>
                      <Link href="/file" className="flex items-center gap-2 px-4 py-3 text-sm text-gray-700 hover:bg-pink/5 hover:text-pink transition-colors">
                        🚀 File a Case
                      </Link>
                      <hr className="border-gray-100" />
                      <button onClick={handleSignOut} className="flex items-center gap-2 px-4 py-3 text-sm text-red-500 hover:bg-red-50 transition-colors w-full">
                        <LogOut size={14} /> Sign Out
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <>
                <Link href="/login" className="border-2 border-pink text-pink px-4 py-2 rounded-full font-semibold text-sm hover:bg-pink hover:text-white transition-all">
                  Login
                </Link>
                <Link href="/file" className="bg-pink text-white px-4 py-2 rounded-full font-semibold text-sm shadow-[0_4px_14px_rgba(222,24,199,0.3)] hover:-translate-y-0.5 hover:shadow-[0_8px_22px_rgba(222,24,199,0.4)] transition-all">
                  File a Case 🚀
                </Link>
              </>
            )}
          </div>

          {/* Hamburger */}
          <button
            onClick={() => setMobileOpen(m => !m)}
            className="lg:hidden flex-shrink-0 text-pink p-1"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-16 left-0 w-full bg-white z-40 shadow-xl max-h-[calc(100vh-64px)] overflow-y-auto lg:hidden"
          >
            <ul className="list-none py-2">
              {NAV_LINKS.map(link => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="block px-6 py-4 text-gray-700 font-medium border-b border-gray-50 hover:text-pink hover:bg-pink/5 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="flex gap-3 px-6 py-4 border-t-2 border-gray-100">
              {user ? (
                <button onClick={handleSignOut} className="flex-1 py-3 border-2 border-red-200 text-red-500 rounded-full font-semibold text-sm">
                  Sign Out
                </button>
              ) : (
                <>
                  <Link href="/login" onClick={() => setMobileOpen(false)} className="flex-1 py-3 text-center border-2 border-pink text-pink rounded-full font-semibold text-sm">Login</Link>
                  <Link href="/file"  onClick={() => setMobileOpen(false)} className="flex-1 py-3 text-center bg-pink text-white rounded-full font-semibold text-sm">File a Case</Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay to close user menu */}
      {userMenu && <div className="fixed inset-0 z-40" onClick={() => setUserMenu(false)} />}
    </>
  )
}
