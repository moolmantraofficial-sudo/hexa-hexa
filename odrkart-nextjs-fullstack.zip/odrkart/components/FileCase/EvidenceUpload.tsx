// components/FileCase/EvidenceUpload.tsx
'use client'

import { useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { motion, AnimatePresence } from 'framer-motion'
import { useCaseStore } from '@/store/caseStore'
import { useFileUpload } from '@/hooks/useFileUpload'
import { Upload, FileText, Image, Film, Trash2, CheckCircle, AlertCircle } from 'lucide-react'

const ACCEPTED = {
  'application/pdf': ['.pdf'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
  'video/mp4': ['.mp4'],
}

const FILE_ICON: Record<string, React.ReactNode> = {
  pdf:  <FileText size={18} className="text-red-400" />,
  doc:  <FileText size={18} className="text-blue-400" />,
  docx: <FileText size={18} className="text-blue-400" />,
  jpg:  <Image size={18} className="text-green-400" />,
  jpeg: <Image size={18} className="text-green-400" />,
  png:  <Image size={18} className="text-green-400" />,
  mp4:  <Film size={18} className="text-purple-400" />,
}

interface EvidenceUploadProps {
  caseId: string
}

export default function EvidenceUpload({ caseId }: EvidenceUploadProps) {
  const { files, removeFile }   = useCaseStore()
  const { uploadFiles, isUploading, error } = useFileUpload()

  const onDrop = useCallback((accepted: File[]) => {
    if (!caseId) {
      console.warn('No caseId – save step 1 first')
      return
    }
    uploadFiles(accepted, caseId)
  }, [uploadFiles, caseId])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED,
    maxSize: 52_428_800,
    multiple: true,
  })

  const formatSize = (bytes: number) =>
    bytes > 1_048_576 ? `${(bytes / 1_048_576).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`

  return (
    <div className="space-y-4">
      {/* Drop zone */}
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-300 ${
          isDragActive
            ? 'border-pink bg-pink-light scale-[1.01]'
            : 'border-pink/35 bg-pink/3 hover:border-pink hover:bg-pink/6'
        }`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-3">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
            isDragActive ? 'bg-gradient-to-br from-pink to-purple scale-110' : 'bg-gradient-to-br from-pink/20 to-purple/20'
          }`}>
            <Upload size={24} className={isDragActive ? 'text-white' : 'text-pink'} />
          </div>
          <div>
            <p className="font-bold text-dark">
              {isDragActive ? 'Drop to upload!' : <><span className="text-pink">Click to upload</span> or drag &amp; drop</>}
            </p>
            <p className="text-muted text-sm mt-1">PDF, DOCX, JPG, PNG, MP4 · Max 50 MB per file</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-red-600 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {/* File list */}
      <AnimatePresence>
        {files.map(file => {
          const ext = file.name.split('.').pop()?.toLowerCase() ?? ''
          return (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex items-center gap-3 bg-gray-50 border border-pink/18 rounded-xl px-4 py-3"
            >
              <div className="flex-shrink-0">{FILE_ICON[ext] ?? <FileText size={18} className="text-gray-400" />}</div>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-dark truncate">{file.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  {/* Progress bar */}
                  <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        file.status === 'done'  ? 'bg-gradient-to-r from-green-400 to-green-500' :
                        file.status === 'error' ? 'bg-red-400' :
                        'bg-gradient-to-r from-pink to-purple'
                      }`}
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                  <span className={`text-xs font-bold min-w-[28px] ${
                    file.status === 'done' ? 'text-green-500' :
                    file.status === 'error' ? 'text-red-500' : 'text-pink'
                  }`}>
                    {file.status === 'done' ? '✓' : file.status === 'error' ? '!' : `${file.progress}%`}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                <span className="text-xs text-gray-400">{formatSize(file.size)}</span>
                {file.status === 'done' && <CheckCircle size={16} className="text-green-500" />}
                {file.status === 'error' && <AlertCircle size={16} className="text-red-500" />}
                <button
                  onClick={() => removeFile(file.id)}
                  className="text-gray-300 hover:text-red-400 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </motion.div>
          )
        })}
      </AnimatePresence>

      {isUploading && (
        <p className="text-center text-muted text-sm flex items-center justify-center gap-2">
          <span className="w-3 h-3 rounded-full border-2 border-pink/30 border-t-pink animate-spin" />
          Uploading to secure storage…
        </p>
      )}
    </div>
  )
}
