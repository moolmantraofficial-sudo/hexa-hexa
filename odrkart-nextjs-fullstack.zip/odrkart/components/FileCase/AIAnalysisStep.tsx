// components/FileCase/AIAnalysisStep.tsx
'use client'
/**
 * AIAnalysisStep
 * Calls the *backend* /api/ai/analyse route (which holds the API key securely)
 * instead of calling Claude directly from the browser.
 * Shows animated scan steps, then renders dual Company + Client reports.
 */

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useCaseStore } from '@/store/caseStore'
import { CheckCircle, ChevronRight } from 'lucide-react'

const SCAN_STEPS = [
  'Reading case information',
  'Identifying parties and claims',
  'Reviewing evidence documents',
  'Assessing legal merit & risk',
  'Generating Company Report',
  'Generating Client Report',
]

type Tab = 'company' | 'client'

export default function AIAnalysisStep({ onComplete }: { onComplete: () => void }) {
  const { step1, step2, files, caseId, aiReport, setAIReport } = useCaseStore()
  const [scanning,    setScanning]    = useState(false)
  const [scanStep,    setScanStep]    = useState(-1)
  const [activeTab,   setActiveTab]   = useState<Tab>('company')
  const [error,       setError]       = useState<string | null>(null)
  const [showReports, setShowReports] = useState(!!aiReport)

  // Auto-show if already generated
  useEffect(() => { if (aiReport) setShowReports(true) }, [aiReport])

  const runAnalysis = async () => {
    if (!caseId) { setError('Please save case info first'); return }
    setScanning(true)
    setError(null)
    setShowReports(false)
    setScanStep(0)

    // Animate scan steps
    const stepInterval = setInterval(() => {
      setScanStep(s => {
        if (s >= SCAN_STEPS.length - 1) { clearInterval(stepInterval); return s }
        return s + 1
      })
    }, 700)

    try {
      const res = await fetch('/api/ai/analyse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId,
          title:       step1.title,
          category:    step1.category,
          amount:      step1.claimAmount,
          resolution:  step1.resolutionType,
          description: step1.description,
          claimant:    step2.claimantName,
          respondent:  step2.respondentName,
          documents:   files.map(f => f.name).join(', ') || 'None',
        }),
      })

      clearInterval(stepInterval)
      setScanStep(SCAN_STEPS.length - 1)

      if (!res.ok) throw new Error(await res.text())
      const data = await res.json()

      setAIReport({
        companyReport: data.companyReport,
        clientReport:  data.clientReport,
        legalMerit:    data.legalMerit,
        riskLevel:     data.riskLevel,
        generatedAt:   data.generatedAt,
      })

      await new Promise(r => setTimeout(r, 600))
      setShowReports(true)
    } catch (e: unknown) {
      clearInterval(stepInterval)
      setError(e instanceof Error ? e.message : 'Analysis failed')
    } finally {
      setScanning(false)
    }
  }

  // Parse sections from raw report text
  const parseSections = (text: string, headers: string[]) => {
    const sections: Record<string, string> = {}
    for (let i = 0; i < headers.length; i++) {
      const key   = headers[i]
      const start = text.indexOf(key)
      if (start === -1) continue
      const nextKey  = headers[i + 1]
      const end      = nextKey ? text.indexOf(nextKey) : text.length
      sections[key]  = text.slice(start + key.length, end).replace(/^[\s:\-–—]+/, '').trim()
    }
    return sections
  }

  const companyHeaders = ['CASE OVERVIEW','LEGAL MERIT ASSESSMENT','RISK ANALYSIS','PANELIST RECOMMENDATION','RESOLUTION TIMELINE','INTERNAL NOTES']
  const clientHeaders  = ['CASE SUMMARY','YOUR LEGAL POSITION','WHAT HAPPENS NEXT','DOCUMENTS CHECKLIST REVIEW','TIPS FOR A STRONG CASE','ESTIMATED OUTCOME']

  const merit = aiReport?.legalMerit ?? 0
  const meritColor = merit >= 75 ? 'text-green-500' : merit >= 50 ? 'text-amber-500' : 'text-red-500'

  return (
    <div className="space-y-6">
      {/* AI Header */}
      <div className="flex items-center gap-4 p-5 bg-gradient-to-r from-[#0d0d20] to-[#180d30] rounded-2xl border border-purple-deep/30">
        <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-[#7c3aed] to-[#a855f7] flex items-center justify-center text-2xl animate-ai-glow flex-shrink-0">
          🧠
        </div>
        <div className="flex-1">
          <h4 className="text-[#e0cfff] font-extrabold text-base">ODRkart AI Document Analyser</h4>
          <p className="text-[#8b7aa8] text-sm mt-0.5">Generates separate Company &amp; Client reports securely on our servers</p>
        </div>
        <span className="bg-[#2ecc71]/12 border border-[#2ecc71]/30 text-[#2ecc71] text-xs font-bold px-3 py-1 rounded-full">
          ✦ AI Powered
        </span>
      </div>

      {/* Context summary */}
      <div className="bg-[#f9f7ff] border border-[#7c3aed]/15 rounded-2xl p-5">
        <p className="text-xs font-extrabold text-[#7c3aed] uppercase tracking-widest mb-3">📋 Inputs Being Analysed</p>
        <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
          <div><span className="font-bold text-[#7c3aed] text-xs">📋 Case:</span> {step1.title || 'Not set'}</div>
          <div><span className="font-bold text-[#7c3aed] text-xs">⚖️ Type:</span> {step1.category || 'Not set'}</div>
          <div><span className="font-bold text-[#7c3aed] text-xs">💰 Claim:</span> {step1.claimAmount ? `₹${Number(step1.claimAmount).toLocaleString('en-IN')}` : 'Not set'}</div>
          <div><span className="font-bold text-[#7c3aed] text-xs">📂 Docs:</span> {files.length} uploaded</div>
        </div>
      </div>

      {/* Trigger button */}
      {!scanning && (
        <button
          onClick={runAnalysis}
          disabled={scanning}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#7c3aed] via-[#a855f7] to-[#de18c7] text-white font-extrabold text-base flex items-center justify-center gap-3 shadow-xl hover:-translate-y-0.5 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
        >
          <span>✦</span>
          {aiReport ? 'Re-run AI Analysis' : 'Run AI Analysis & Generate Reports'}
        </button>
      )}

      {/* Scanning animation */}
      <AnimatePresence>
        {scanning && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-4 p-6 bg-gradient-to-b from-[#7c3aed]/6 to-[#a855f7]/4 border border-[#a855f7]/18 rounded-2xl"
          >
            <div className="relative w-20 h-20">
              <div className="w-20 h-20 rounded-full border-3 border-[#a855f7]/15 border-t-[#a855f7] animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center text-2xl">🧠</div>
            </div>
            <div className="text-center">
              <p className="text-[#c4b5d8] font-bold">Analysing your case…</p>
              <p className="text-[#6b5d7a] text-sm mt-1">{SCAN_STEPS[scanStep] ?? 'Processing…'}</p>
            </div>
            <div className="w-full max-w-sm space-y-2">
              {SCAN_STEPS.map((step, i) => (
                <div key={i} className={`flex items-center gap-3 text-sm transition-all ${
                  i < scanStep ? 'text-[#a78bfa]' : i === scanStep ? 'text-[#c4b5fd] font-semibold' : 'text-[#8b7aa8]'
                }`}>
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center text-xs flex-shrink-0 ${
                    i < scanStep  ? 'bg-[#a78bfa]/20 border-[#a78bfa] text-[#a78bfa]' :
                    i === scanStep ? 'bg-[#a855f7]/30 border-[#c4b5fd] animate-pulse' :
                    'border-[#a855f7]/30'
                  }`}>
                    {i < scanStep ? '✓' : i + 1}
                  </div>
                  {step}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-600 text-sm text-center">
          ⚠️ {error}
        </div>
      )}

      {/* Reports */}
      <AnimatePresence>
        {showReports && aiReport && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            {/* Score row */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white rounded-2xl p-4 text-center border border-gray-100 shadow-card">
                <div className={`text-2xl font-black font-mono ${meritColor}`}>{merit}/100</div>
                <div className="text-gray-500 text-xs mt-1">Legal Merit</div>
              </div>
              <div className="bg-white rounded-2xl p-4 text-center border border-gray-100 shadow-card">
                <div className={`text-2xl font-black font-mono capitalize ${
                  aiReport.riskLevel === 'low' ? 'text-green-500' : aiReport.riskLevel === 'high' ? 'text-red-500' : 'text-amber-500'
                }`}>{aiReport.riskLevel}</div>
                <div className="text-gray-500 text-xs mt-1">Risk Level</div>
              </div>
              <div className="bg-white rounded-2xl p-4 text-center border border-gray-100 shadow-card">
                <div className="text-2xl font-black font-mono text-green-500">✓</div>
                <div className="text-gray-500 text-xs mt-1">AI Verified</div>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 bg-gray-100 rounded-2xl p-1">
              {(['company', 'client'] as Tab[]).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-2.5 rounded-xl font-bold text-sm transition-all ${
                    activeTab === tab
                      ? `bg-white shadow-sm ${tab === 'company' ? 'text-[#7c3aed]' : 'text-pink'}`
                      : 'text-gray-400'
                  }`}
                >
                  {tab === 'company' ? '🏢 Company Report' : '👤 Client Report'}
                </button>
              ))}
            </div>

            {/* Report content */}
            <div className="rounded-2xl overflow-hidden border border-gray-100 shadow-card">
              <div className={`px-5 py-4 flex items-center gap-3 ${
                activeTab === 'company'
                  ? 'bg-gradient-to-r from-[#0f0a2a] to-[#1e1040]'
                  : 'bg-gradient-to-r from-[#1a0a22] to-[#2a0a30]'
              }`}>
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl ${
                  activeTab === 'company'
                    ? 'bg-gradient-to-br from-[#7c3aed] to-[#6366f1]'
                    : 'bg-gradient-to-br from-[#de18c7] to-[#9b59b6]'
                }`}>
                  {activeTab === 'company' ? '🏢' : '👤'}
                </div>
                <div>
                  <h4 className="text-white font-extrabold">
                    {activeTab === 'company' ? 'Internal Company Analysis' : 'Client Case Summary'}
                  </h4>
                  <p className="text-gray-400 text-xs mt-0.5">
                    ODRkart · {activeTab === 'company' ? 'Confidential' : 'Claimant Copy'} · {new Date().toLocaleDateString('en-IN')}
                  </p>
                </div>
                <span className={`ml-auto text-xs font-bold px-2 py-1 rounded-xl border ${
                  activeTab === 'company'
                    ? 'bg-white/8 text-[#c4b5fd] border-white/10'
                    : 'bg-white/8 text-[#f0c0f5] border-white/10'
                }`}>
                  {activeTab === 'company' ? 'CONFIDENTIAL' : 'CLIENT COPY'}
                </span>
              </div>
              <div className="bg-[#faf8ff] p-5 space-y-4 max-h-80 overflow-y-auto">
                {Object.entries(
                  parseSections(
                    activeTab === 'company' ? aiReport.companyReport : aiReport.clientReport,
                    activeTab === 'company' ? companyHeaders : clientHeaders
                  )
                ).map(([header, content]) => (
                  <div key={header}>
                    <div className={`text-xs font-extrabold uppercase tracking-widest mb-2 flex items-center gap-2 ${
                      activeTab === 'company' ? 'text-[#7c3aed]' : 'text-pink'
                    }`}>
                      {activeTab === 'company' ? '🏢' : '👤'} {header}
                      <span className="flex-1 h-px bg-current opacity-20" />
                    </div>
                    <p className="text-gray-600 text-sm leading-7 whitespace-pre-line">{content}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Proceed button */}
            <button
              onClick={onComplete}
              className="w-full py-3.5 rounded-full bg-gradient-to-r from-pink to-purple text-white font-bold flex items-center justify-center gap-2 shadow-pink hover:-translate-y-0.5 transition-all"
            >
              Continue to Resolution Preferences <ChevronRight size={18} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
