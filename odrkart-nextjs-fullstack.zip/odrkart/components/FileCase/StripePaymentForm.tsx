// components/FileCase/StripePaymentForm.tsx
'use client'
/**
 * StripePaymentForm
 * Uses @stripe/react-stripe-js with the Payment Element.
 * Handles PaymentIntent creation, confirmation, and success callback.
 */

import { useState, useEffect } from 'react'
import { loadStripe } from '@stripe/stripe-js'
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

interface StripePaymentFormProps {
  caseId:   string
  onSuccess: (paymentIntentId: string) => void
}

// ── Inner form (must live inside <Elements>) ──────────────────────────────────
function CheckoutForm({ onSuccess }: { onSuccess: (id: string) => void }) {
  const stripe   = useStripe()
  const elements = useElements()
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!stripe || !elements) return

    setLoading(true)
    setError(null)

    const { error: stripeError, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/file/success`,
      },
      redirect: 'if_required',  // Stay on page if possible
    })

    if (stripeError) {
      setError(stripeError.message ?? 'Payment failed')
      setLoading(false)
    } else if (paymentIntent?.status === 'succeeded') {
      onSuccess(paymentIntent.id)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Stripe Payment Element renders cards, Apple Pay, Google Pay etc. */}
      <PaymentElement
        options={{
          layout: 'tabs',
          fields: { billingDetails: { address: { country: 'never' } } },
        }}
      />

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-red-600 text-sm flex items-center gap-2">
          <span>⚠️</span> {error}
        </div>
      )}

      {/* Amount reminder */}
      <div className="bg-gradient-to-r from-[#f5f4ff] to-[#efe8ff] border border-[#635bff]/18 rounded-xl px-4 py-3 flex justify-between items-center">
        <span className="text-gray-600 text-sm font-semibold">Total (incl. GST)</span>
        <span className="text-[#635bff] font-black text-xl">₹1,999</span>
      </div>

      <button
        type="submit"
        disabled={!stripe || loading}
        className={`w-full py-3.5 rounded-full font-bold text-white transition-all flex items-center justify-center gap-2 ${
          loading || !stripe
            ? 'bg-[#635bff]/60 cursor-not-allowed'
            : 'bg-gradient-to-r from-[#635bff] to-[#4f46e5] hover:-translate-y-0.5 shadow-stripe'
        }`}
      >
        {loading ? (
          <>
            <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
            Processing…
          </>
        ) : (
          <>🔒 Pay ₹1,999 Securely</>
        )}
      </button>

      <p className="text-center text-gray-400 text-xs flex items-center justify-center gap-1">
        <span>🔒</span> 256-bit TLS · PCI DSS Level 1 · Powered by <strong className="text-[#635bff]">Stripe</strong>
      </p>
    </form>
  )
}

// ── Outer wrapper: creates PaymentIntent then mounts Elements ─────────────────
export default function StripePaymentForm({ caseId, onSuccess }: StripePaymentFormProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null)
  const [initError,    setInitError]    = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/payments/create-intent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ caseId }),
    })
      .then(r => r.json())
      .then(d => {
        if (d.error) throw new Error(d.error)
        setClientSecret(d.clientSecret)
      })
      .catch(e => setInitError(e.message))
  }, [caseId])

  if (initError) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-600 text-sm text-center">
        ⚠️ Could not initialise payment. {initError}
      </div>
    )
  }

  if (!clientSecret) {
    return (
      <div className="flex justify-center py-8">
        <div className="w-8 h-8 rounded-full border-2 border-[#635bff]/20 border-t-[#635bff] animate-spin" />
      </div>
    )
  }

  return (
    <Elements
      stripe={stripePromise}
      options={{
        clientSecret,
        appearance: {
          theme: 'stripe',
          variables: {
            colorPrimary:  '#635bff',
            colorText:     '#1a1a2e',
            borderRadius:  '10px',
            fontFamily:    'DM Sans, sans-serif',
          },
        },
      }}
    >
      <CheckoutForm onSuccess={onSuccess} />
    </Elements>
  )
}
