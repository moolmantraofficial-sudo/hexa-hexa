// components/Landing/AIPill.tsx
'use client'
/**
 * AI Summary Pill + slide-up panel.
 * Fetches /api/ai/summary (backend route) on first open.
 * NEVER calls Anthropic directly from the browser.
 */

import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'

interface Summary {
  'SECTION 1 — PLATFORM OVERVIEW': string
  'SECTION 2 — KEY STRENGTHS': string
  "SECTION 3 — WHO IT'S FOR": string
  'SECTION 4 — AI VERDICT': string
}

const SECTION_LABELS: Record<string, string> = {
  'SECTION 1 — PLATFORM OVERVIEW': '🏛️ Platform Overview',
  'SECTION 2 — KEY STRENGTHS':      '⚡ Key Strengths',
  "SECTION 3 — WHO IT'S FOR":       '🎯 Who It\'s For',
  'SECTION 4 — AI VERDICT':         '✦ AI Verdict',
}

function parseSummary(raw: string): Record<string, string> {
  const keys  = Object.keys(SECTION_LABELS)
  const out: Record<string, string> = {}
  keys.forEach((key, i) => {
    const start = raw.indexOf(key)
    if (start === -1) return
    const next  = keys[i + 1]
    const end   = next ? raw.indexOf(next) : raw.length
    out[key]    = raw.slice(start + key.length, end).replace(/^[\s:\-–—]+/, '').trim()
  })
  return out
}

export default function AIPill() {
  const [open,      setOpen]      = useState(false)
  const [loading,   setLoading]   = useState(false)
  const [parsed,    setParsed]    = useState<Record<string, string> | null>(null)
  const [error,     setError]     = useState<string | null>(null)
  const [fetched,   setFetched]   = useState(false)

  const fetchSummary = useCallback(async () => {
    if (fetched) return
    setLoading(true)
    try {
      const res  = await fetch('/api/ai/summary')
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setParsed(parseSummary(data.summary))
      setFetched(true)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'AI unavailable')
    }
    setLoading(false)
  }, [fetched])

  const handleOpen = () => {
    setOpen(true)
    fetchSummary()
  }

  const handleRegen = () => {
    setFetched(false)
    setParsed(null)
    setError(null)
    setLoading(true)
    // Force re-fetch
    fetch('/api/ai/summary?regen=1')
      .then(r => r.json())
      .then(d => { if (d.summary) { setParsed(parseSummary(d.summary)); setFetched(true) } })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }

  return (
    <>
      {/* Floating pill */}
      <motion.button
        onClick={handleOpen}
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1.5, type: 'spring', stiffness: 200 }}
        whileHover={{ y: -3 }}
        className="fixed bottom-7 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-gradient-to-r from-[#c0108a] to-[#de18c7] text-white px-5 py-3 rounded-full font-bold text-sm shadow-[0_0_22px_rgba(222,24,199,0.45),0_4px_18px_rgba(0,0,0,0.3)] border border-[#ff64dc]/50 backdrop-blur-md whitespace-nowrap hover:shadow-[0_0_36px_rgba(222,24,199,0.7)] transition-shadow"
      >
        <span className="w-7 h-7 rounded-full bg-white/25 flex items-center justify-center text-sm animate-ai-glow">✦</span>
        <span>Explore AI Summary</span>
        <span className="w-1.5 h-1.5 rounded-full bg-[#a78bfa] animate-pulse" />
      </motion.button>

      {/* Overlay */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 bg-black/55 z-[60] backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[660px] max-h-[88vh] bg-[#0d0d1f] rounded-t-3xl z-[61] flex flex-col border-t border-[#a78bfa]/30 overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center gap-3 px-6 py-4 border-b border-white/7 bg-gradient-to-r from-[#7c3aed]/15 to-[#a855f7]/8 flex-shrink-0">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#7c3aed] to-[#a855f7] flex items-center justify-center text-xl flex-shrink-0">🧠</div>
                <div className="flex-1">
                  <h4 className="text-[#e0cfff] font-bold">ODRkart AI Summary</h4>
                  <p className="text-[#8b7aa8] text-xs mt-0.5">✦ Real-time AI · Generated on the server</p>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/7 hover:bg-[#a78bfa]/20 text-[#a78bfa] hover:text-white transition-all flex items-center justify-center text-sm"
                >
                  ✕
                </button>
              </div>

              {/* Body */}
              <div className="overflow-y-auto flex-1 px-6 py-5">
                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  {[['12K+','Cases Resolved'],['98%','Satisfaction'],['30D','Avg Resolution']].map(([n,l]) => (
                    <div key={l} className="bg-white/4 border border-[#a78bfa]/15 rounded-xl p-3 text-center">
                      <div className="text-[#a78bfa] text-xl font-black font-mono">{n}</div>
                      <div className="text-[#7c6d8f] text-xs mt-1">{l}</div>
                    </div>
                  ))}
                </div>

                {loading && (
                  <div className="flex flex-col items-center justify-center py-10 gap-4">
                    <div className="w-12 h-12 rounded-full border-3 border-[#a855f7]/15 border-t-[#a855f7] animate-spin" />
                    <p className="text-[#8b7aa8] text-sm">Generating summary…</p>
                  </div>
                )}

                {error && (
                  <div className="bg-red-500/8 border border-red-400/25 rounded-xl p-4 text-[#fca5a5] text-sm text-center">
                    ⚠️ {error}
                  </div>
                )}

                {parsed && Object.entries(SECTION_LABELS).map(([key, label]) => (
                  parsed[key] ? (
                    <div key={key} className="mb-5">
                      <div className="flex items-center gap-2 text-[#a78bfa] text-xs font-bold uppercase tracking-widest mb-2">
                        {label}
                        <span className="flex-1 h-px bg-[#a78bfa]/18" />
                      </div>
                      <p className="text-[#c4b5d8] text-sm leading-relaxed">{parsed[key]}</p>
                    </div>
                  ) : null
                ))}

                {/* Actions */}
                {!loading && (
                  <div className="flex gap-3 mt-2 pt-4 border-t border-white/7">
                    <button
                      onClick={handleRegen}
                      className="flex-1 py-2.5 rounded-xl border border-[#a78bfa]/25 bg-[#7c3aed]/12 text-[#a78bfa] text-sm font-semibold hover:bg-[#7c3aed]/25 hover:border-[#a78bfa]/50 transition-all"
                    >
                      ↺ Regenerate
                    </button>
                    <Link
                      href="/file"
                      onClick={() => setOpen(false)}
                      className="flex-1 py-2.5 rounded-xl bg-[#7c3aed]/25 border border-[#a78bfa]/25 text-[#a78bfa] text-sm font-semibold hover:bg-[#7c3aed]/40 transition-all text-center"
                    >
                      🚀 File a Dispute
                    </Link>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
