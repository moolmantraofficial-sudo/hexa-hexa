// components/Landing/AILabBlog.tsx
'use client'
/**
 * AI Lab Blog section
 * Calls /api/ai/blog (server route with Anthropic key) to generate posts.
 * NEVER calls Claude directly from the browser.
 */

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

type Topic = 'all' | 'arbitration' | 'technology' | 'consumer' | 'international'

interface BlogPost {
  title:    string
  excerpt:  string
  category: string
  readTime: string
  author:   string
  emoji:    string
}

const TOPIC_LABELS: Record<Topic, string> = {
  all:           '🌐 All Topics',
  arbitration:   '⚖️ Arbitration',
  technology:    '🤖 Legal Tech',
  consumer:      '👤 Consumer',
  international: '🌍 International',
}

const POST_BGSECTIONS = [
  'from-[#7c3aed]/15 to-[#a855f7]/8',
  'from-[#de18c7]/12 to-[#6366f1]/8',
  'from-[#2ecc71]/10 to-[#3b82f6]/8',
  'from-[#f59e0b]/10 to-[#ef4444]/8',
  'from-[#8b5cf6]/15 to-[#3b82f6]/8',
  'from-[#ec4899]/10 to-[#a855f7]/8',
]

function SkeletonCard() {
  return (
    <div className="bg-white/4 border border-white/8 rounded-2xl overflow-hidden">
      <div className="h-36 bg-white/4 flex items-center justify-center">
        <div className="w-14 h-14 rounded-full bg-white/6 animate-skel" />
      </div>
      <div className="p-5 space-y-3">
        <div className="h-4 bg-white/6 rounded-lg animate-skel w-4/5" />
        <div className="h-3 bg-white/6 rounded-lg animate-skel w-full" />
        <div className="h-3 bg-white/6 rounded-lg animate-skel w-2/3" />
      </div>
    </div>
  )
}

export default function AILabBlog() {
  const [posts,     setPosts]     = useState<BlogPost[]>([])
  const [topic,     setTopic]     = useState<Topic>('all')
  const [loading,   setLoading]   = useState(false)
  const [status,    setStatus]    = useState('')
  const [expanded,  setExpanded]  = useState<number | null>(null)
  const sectionRef  = useRef<HTMLElement>(null)
  const triggered   = useRef(false)

  const fetchPosts = async (t: Topic = topic) => {
    setLoading(true)
    setStatus('✦ AI is writing articles…')
    setPosts([])
    try {
      const res = await fetch('/api/ai/blog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: t, count: 4 }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setPosts(data.posts)
      setStatus(`✦ ${data.posts.length} articles published · ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`)
    } catch (e: unknown) {
      setStatus('⚠️ Generation failed')
      console.error(e)
    }
    setLoading(false)
  }

  // Auto-trigger on scroll into view
  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && !triggered.current) {
        triggered.current = true
        observer.disconnect()
        setTimeout(() => fetchPosts(), 600)
      }
    }, { threshold: 0.15 })
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleTopicChange = (t: Topic) => {
    setTopic(t)
    fetchPosts(t)
  }

  return (
    <section
      id="ailab"
      ref={sectionRef}
      className="relative py-24 px-6 bg-gradient-to-br from-[#07071a] via-[#0f0820] to-[#060f1a] overflow-hidden"
    >
      {/* Animated orbs */}
      <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] rounded-full bg-radial-gradient pointer-events-none animate-orb-1 opacity-15"
        style={{ background: 'radial-gradient(circle, rgba(124,58,237,1), transparent 65%)' }} />
      <div className="absolute bottom-[-80px] right-[-80px] w-[400px] h-[400px] rounded-full pointer-events-none animate-orb-2 opacity-10"
        style={{ background: 'radial-gradient(circle, rgba(222,24,199,1), transparent 65%)' }} />
      {/* Grid texture */}
      <div className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.015) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.015) 1px,transparent 1px)', backgroundSize: '48px 48px' }} />

      <div className="relative z-10 max-w-[1280px] mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-[#7c3aed]/15 border border-[#7c3aed]/35 text-[#a78bfa] px-4 py-1.5 rounded-full text-xs font-bold tracking-wide mb-4">
            🧠 Powered by ODRkart AI · Auto-Publishing
          </div>
          <h2 className="text-white text-4xl font-black mb-3">
            ODRkart <span className="bg-gradient-to-r from-[#de18c7] via-[#a855f7] to-[#6366f1] bg-clip-text text-transparent">AI Lab Blog</span>
          </h2>
          <p className="text-[#5a5a7a] text-base">Cutting-edge articles generated automatically by our AI — refreshing legal insights daily</p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
          <button
            onClick={() => fetchPosts()}
            disabled={loading}
            className="flex items-center gap-2 bg-gradient-to-r from-[#7c3aed] via-[#a855f7] to-[#de18c7] text-white px-6 py-3 rounded-full font-bold text-sm shadow-[0_6px_24px_rgba(124,58,237,0.4)] hover:-translate-y-0.5 hover:shadow-[0_12px_35px_rgba(124,58,237,0.6)] transition-all disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading
              ? <><span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> Generating…</>
              : <>✦ Generate New Posts</>
            }
          </button>
          {(Object.keys(TOPIC_LABELS) as Topic[]).map(t => (
            <button
              key={t}
              onClick={() => handleTopicChange(t)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-all border ${
                topic === t
                  ? 'bg-[#7c3aed]/25 border-[#a78bfa]/60 text-[#e0cfff]'
                  : 'bg-white/6 border-[#a78bfa]/25 text-[#c4b5fd] hover:bg-[#7c3aed]/20'
              }`}
            >
              {TOPIC_LABELS[t]}
            </button>
          ))}
        </div>

        {/* Posts grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
            : posts.map((post, i) => (
                <motion.div
                  key={`${post.title}-${i}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="bg-white/4 border border-white/8 rounded-2xl overflow-hidden hover:border-[#a78bfa]/35 hover:-translate-y-1 hover:shadow-[0_16px_40px_rgba(124,58,237,0.2)] transition-all"
                >
                  <div className={`h-36 flex items-center justify-center bg-gradient-to-br ${POST_BGSECTIONS[i % POST_BGSECTIONS.length]} relative`}>
                    <span className="text-5xl">{post.emoji}</span>
                    <span className="absolute top-3 left-3 bg-[#7c3aed]/50 backdrop-blur border border-[#a78bfa]/30 text-[#e0cfff] text-xs font-bold px-2.5 py-1 rounded-xl">
                      {post.category}
                    </span>
                    {i < 2 && (
                      <span className="absolute top-3 right-3 bg-[#2ecc71]/20 border border-[#2ecc71]/40 text-[#6ee7b7] text-xs font-bold px-2 py-0.5 rounded-xl">
                        ✦ NEW
                      </span>
                    )}
                  </div>
                  <div className="p-5">
                    <h4 className="text-[#e0cfff] font-extrabold text-sm leading-snug mb-2">{post.title}</h4>
                    <p className="text-[#8b7aa8] text-xs leading-relaxed line-clamp-3">{post.excerpt}</p>
                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/6">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#7c3aed] to-[#a855f7] flex items-center justify-center text-xs">🧠</div>
                        <span className="text-[#6b5d7a] text-xs">{post.readTime}</span>
                      </div>
                      <button
                        onClick={() => setExpanded(expanded === i ? null : i)}
                        className="text-[#a78bfa] text-xs font-semibold hover:text-[#e0cfff] transition-colors"
                      >
                        {expanded === i ? 'Collapse ↑' : 'Read more ↓'}
                      </button>
                    </div>
                    <AnimatePresence>
                      {expanded === i && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden"
                        >
                          <p className="text-[#5a5a7a] text-xs italic mt-3 leading-relaxed">
                            Full article available on request. Click &quot;Generate New Posts&quot; for fresh AI-written content on this topic.
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              ))
          }
        </div>

        {/* Status */}
        <div className="text-center mt-8">
          <span className="text-[#4a4a6a] text-sm">{status}</span>
        </div>
      </div>
    </section>
  )
}
