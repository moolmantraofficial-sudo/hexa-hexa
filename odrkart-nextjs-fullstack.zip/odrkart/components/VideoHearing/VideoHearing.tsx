// components/VideoHearing/VideoHearing.tsx
'use client'
/**
 * VideoHearing
 * Live video hearing component backed by Agora RTC.
 * Fetches a token from /api/video/token, joins the channel, and renders
 * local + remote video streams with full controls.
 */

import { useEffect, useRef, useState, useCallback } from 'react'
import { Mic, MicOff, Video, VideoOff, PhoneOff, ScreenShare, Users, MessageSquare } from 'lucide-react'

interface VideoHearingProps {
  hearingId: string
  role:      'claimant' | 'respondent' | 'panelist' | 'observer'
  caseRef:   string
  onEnd?:    () => void
}

interface RemoteUser {
  uid:         number
  videoTrack?: unknown   // AgoraRTC.IRemoteVideoTrack
  audioTrack?: unknown   // AgoraRTC.IRemoteAudioTrack
}

export default function VideoHearing({ hearingId, role, caseRef, onEnd }: VideoHearingProps) {
  const clientRef    = useRef<unknown>(null)   // AgoraRTCClient
  const localVidRef  = useRef<HTMLDivElement>(null)
  const [joined,       setJoined]       = useState(false)
  const [remoteUsers,  setRemoteUsers]  = useState<RemoteUser[]>([])
  const [localMuted,   setLocalMuted]   = useState(false)
  const [localVideOff, setLocalVideoOff]= useState(false)
  const [duration,     setDuration]     = useState(0)
  const [status,       setStatus]       = useState<'connecting' | 'live' | 'ended'>('connecting')
  const [error,        setError]        = useState<string | null>(null)
  const [localTracks,  setLocalTracks]  = useState<unknown[]>([])

  // Duration timer
  useEffect(() => {
    if (status !== 'live') return
    const id = setInterval(() => setDuration(d => d + 1), 1000)
    return () => clearInterval(id)
  }, [status])

  const formatDuration = (s: number) =>
    `${String(Math.floor(s / 3600)).padStart(2,'0')}:${String(Math.floor((s % 3600) / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`

  // Join hearing
  const joinHearing = useCallback(async () => {
    try {
      // 1. Get Agora token from our backend
      const res   = await fetch('/api/video/token', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hearingId, role }),
      })
      if (!res.ok) throw new Error(await res.text())
      const { token, channel, uid, appId } = await res.json()

      // 2. Dynamically import Agora SDK (large bundle – lazy load)
      const AgoraRTC = (await import('agora-rtc-sdk-ng')).default
      AgoraRTC.setLogLevel(4) // errors only

      const rtcClient = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' })
      clientRef.current = rtcClient

      // 3. Bind remote user events
      rtcClient.on('user-published', async (user: RemoteUser, mediaType: 'video' | 'audio') => {
        await rtcClient.subscribe(user as never, mediaType)
        if (mediaType === 'video') {
          setRemoteUsers(prev => {
            const exists = prev.find(u => u.uid === user.uid)
            return exists
              ? prev.map(u => u.uid === user.uid ? { ...u, videoTrack: user.videoTrack } : u)
              : [...prev, { uid: user.uid, videoTrack: user.videoTrack }]
          })
          // Play remote video in div
          setTimeout(() => {
            const el = document.getElementById(`remote-${user.uid}`)
            if (el && user.videoTrack) (user.videoTrack as { play: (el: HTMLElement) => void }).play(el)
          }, 200)
        }
        if (mediaType === 'audio' && user.audioTrack) {
          (user.audioTrack as { play: () => void }).play()
        }
      })

      rtcClient.on('user-unpublished', (user: RemoteUser) => {
        setRemoteUsers(prev => prev.filter(u => u.uid !== user.uid))
      })
      rtcClient.on('user-left', (user: RemoteUser) => {
        setRemoteUsers(prev => prev.filter(u => u.uid !== user.uid))
      })

      // 4. Join channel
      await rtcClient.join(appId, channel, token, uid)

      // 5. Create and publish local tracks
      const [micTrack, camTrack] = await AgoraRTC.createMicrophoneAndCameraTracks()
      setLocalTracks([micTrack, camTrack])

      if (localVidRef.current) camTrack.play(localVidRef.current)
      await rtcClient.publish([micTrack, camTrack])

      setJoined(true)
      setStatus('live')
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to join hearing')
      setStatus('ended')
    }
  }, [hearingId, role])

  useEffect(() => {
    joinHearing()
    return () => { leaveHearing(false) }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const leaveHearing = async (notify = true) => {
    if (localTracks.length) {
      for (const t of localTracks) (t as { stop: () => void; close: () => void }).stop(), (t as { close: () => void }).close()
    }
    if (clientRef.current) await (clientRef.current as { leave: () => Promise<void> }).leave()
    setStatus('ended')
    if (notify && onEnd) onEnd()
  }

  const toggleMic = async () => {
    const audioTrack = localTracks[0] as { setEnabled: (v: boolean) => Promise<void> } | undefined
    if (!audioTrack) return
    await audioTrack.setEnabled(localMuted)
    setLocalMuted(m => !m)
  }

  const toggleVideo = async () => {
    const videoTrack = localTracks[1] as { setEnabled: (v: boolean) => Promise<void> } | undefined
    if (!videoTrack) return
    await videoTrack.setEnabled(localVideOff)
    setLocalVideoOff(v => !v)
  }

  // ── Render ──────────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div className="flex items-center justify-center h-full bg-[#07071a] rounded-2xl p-8">
        <div className="text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <h3 className="text-white font-bold text-lg mb-2">Could not join hearing</h3>
          <p className="text-[#8b7aa8] text-sm mb-4">{error}</p>
          <button onClick={joinHearing} className="px-6 py-3 bg-gradient-to-r from-[#7c3aed] to-[#de18c7] text-white rounded-full font-bold text-sm">
            ↺ Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-[#07071a] rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#2ecc71]/10 border border-[#2ecc71]/30 text-[#2ecc71] text-xs font-bold px-3 py-1 rounded-full">
            <span className="w-2 h-2 rounded-full bg-[#2ecc71] animate-pulse-dot" />
            {status === 'live' ? 'LIVE HEARING' : 'CONNECTING…'}
          </div>
          <span className="text-[#8b7aa8] text-sm">{caseRef}</span>
        </div>
        <div className="flex items-center gap-4">
          {status === 'live' && (
            <span className="font-mono text-white text-sm bg-white/5 px-3 py-1 rounded-lg">
              {formatDuration(duration)}
            </span>
          )}
          <div className="flex items-center gap-2 text-[#8b7aa8] text-sm">
            <Users size={14} />
            <span>{remoteUsers.length + 1}</span>
          </div>
        </div>
      </div>

      {/* Video grid */}
      <div className="flex-1 p-4 grid gap-3" style={{
        gridTemplateColumns: remoteUsers.length === 0 ? '1fr' : remoteUsers.length === 1 ? '1fr 1fr' : 'repeat(3, 1fr)',
      }}>
        {/* Local video */}
        <div className="relative rounded-xl overflow-hidden bg-[#0d0d20] border border-white/8 aspect-video">
          <div ref={localVidRef} className="absolute inset-0" />
          {localVideOff && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#0d0d20]">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7c3aed] to-[#de18c7] flex items-center justify-center text-white text-2xl font-bold">
                {role[0].toUpperCase()}
              </div>
            </div>
          )}
          <div className="absolute bottom-3 left-3 flex items-center gap-2">
            <span className="bg-black/60 text-white text-xs px-2 py-1 rounded-lg backdrop-blur">
              You ({role})
            </span>
            {localMuted && <span className="bg-red-500/80 text-white text-xs px-2 py-1 rounded-lg"><MicOff size={10} /></span>}
          </div>
        </div>

        {/* Remote users */}
        {remoteUsers.map(u => (
          <div key={u.uid} className="relative rounded-xl overflow-hidden bg-[#0d0d20] border border-white/8 aspect-video">
            <div id={`remote-${u.uid}`} className="absolute inset-0" />
            <div className="absolute bottom-3 left-3">
              <span className="bg-black/60 text-white text-xs px-2 py-1 rounded-lg backdrop-blur">
                Participant {u.uid}
              </span>
            </div>
          </div>
        ))}

        {/* Waiting placeholder */}
        {status === 'connecting' && (
          <div className="flex items-center justify-center bg-[#0d0d20] rounded-xl border border-white/8 aspect-video">
            <div className="text-center">
              <div className="w-8 h-8 rounded-full border-2 border-[#7c3aed]/30 border-t-[#a855f7] animate-spin mx-auto mb-3" />
              <p className="text-[#8b7aa8] text-sm">Connecting to hearing…</p>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-4 py-5 border-t border-white/5">
        <button
          onClick={toggleMic}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
            localMuted ? 'bg-red-500/20 border border-red-500/40 text-red-400' : 'bg-white/8 border border-white/12 text-white hover:bg-white/15'
          }`}
        >
          {localMuted ? <MicOff size={18} /> : <Mic size={18} />}
        </button>
        <button
          onClick={toggleVideo}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
            localVideOff ? 'bg-red-500/20 border border-red-500/40 text-red-400' : 'bg-white/8 border border-white/12 text-white hover:bg-white/15'
          }`}
        >
          {localVideOff ? <VideoOff size={18} /> : <Video size={18} />}
        </button>
        <button className="w-12 h-12 rounded-full flex items-center justify-center bg-white/8 border border-white/12 text-white hover:bg-white/15 transition-all">
          <ScreenShare size={18} />
        </button>
        <button className="w-12 h-12 rounded-full flex items-center justify-center bg-white/8 border border-white/12 text-white hover:bg-white/15 transition-all">
          <MessageSquare size={18} />
        </button>
        <button
          onClick={() => leaveHearing(true)}
          className="w-14 h-12 rounded-full flex items-center justify-center bg-red-500 text-white hover:bg-red-600 transition-all shadow-lg"
        >
          <PhoneOff size={18} />
        </button>
      </div>
    </div>
  )
}
