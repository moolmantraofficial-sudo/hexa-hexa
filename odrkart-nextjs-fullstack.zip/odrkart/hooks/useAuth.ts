// hooks/useAuth.ts
'use client'

import { useEffect, useState } from 'react'
import type { Session, User } from '@supabase/supabase-js'
import { createBrowserSupabase } from '@/lib/supabase'

interface AuthState {
  session:  Session | null
  user:     User | null
  loading:  boolean
  signOut:  () => Promise<void>
}

export function useAuth(): AuthState {
  const supabase = createBrowserSupabase()
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setLoading(false)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })

    return () => subscription.unsubscribe()
  }, [supabase])

  const signOut = async () => {
    await supabase.auth.signOut()
    setSession(null)
  }

  return { session, user: session?.user ?? null, loading, signOut }
}
