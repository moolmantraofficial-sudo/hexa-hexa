// hooks/useFileUpload.ts
'use client'
// Handles the two-step upload flow:
// 1. GET presigned PUT URL from /api/upload
// 2. PUT file directly to S3 with XMLHttpRequest (for progress tracking)

import { useState, useCallback } from 'react'
import { useCaseStore } from '@/store/caseStore'
import { nanoid } from 'crypto'

interface UseFileUploadReturn {
  uploadFiles: (files: File[], caseId: string) => Promise<void>
  isUploading: boolean
  error:       string | null
}

export function useFileUpload(): UseFileUploadReturn {
  const { addFile, updateFileProgress } = useCaseStore()
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const uploadSingleFile = useCallback(async (file: File, caseId: string) => {
    const fileId = Math.random().toString(36).slice(2, 10)

    // Register in store with 0% progress
    addFile({
      id: fileId, name: file.name, size: file.size,
      mimeType: file.type, s3Key: '', docId: '',
      progress: 0, status: 'uploading',
    })

    try {
      // Step 1: get presigned URL from our API
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId,
          fileName: file.name,
          mimeType: file.type,
          fileSize: file.size,
          docType: 'evidence',
        }),
      })
      if (!res.ok) throw new Error(await res.text())
      const { uploadUrl, s3Key, documentId } = await res.json()

      // Step 2: PUT directly to S3 with progress
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open('PUT', uploadUrl)
        xhr.setRequestHeader('Content-Type', file.type)

        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const pct = Math.round((e.loaded / e.total) * 100)
            updateFileProgress(fileId, pct)
          }
        }
        xhr.onload = () => {
          if (xhr.status === 200) {
            updateFileProgress(fileId, 100, 'done', s3Key, documentId)
            resolve()
          } else {
            reject(new Error(`S3 upload failed: ${xhr.status}`))
          }
        }
        xhr.onerror = () => reject(new Error('Network error during upload'))
        xhr.send(file)
      })
    } catch (e: unknown) {
      updateFileProgress(fileId, 0, 'error')
      throw e
    }
  }, [addFile, updateFileProgress])

  const uploadFiles = useCallback(async (files: File[], caseId: string) => {
    setIsUploading(true)
    setError(null)
    try {
      await Promise.allSettled(files.map(f => uploadSingleFile(f, caseId)))
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Upload failed')
    } finally {
      setIsUploading(false)
    }
  }, [uploadSingleFile])

  return { uploadFiles, isUploading, error }
}
