// tailwind.config.ts
import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans:  ['var(--font-dm-sans)', 'DM Sans', 'sans-serif'],
        mono:  ['var(--font-mono)', 'JetBrains Mono', 'monospace'],
      },
      colors: {
        pink:   { DEFAULT: '#de18c7', light: 'rgba(222,24,199,0.1)', dark: '#c0108a' },
        purple: { DEFAULT: '#9b59b6', deep: '#7c3aed' },
        dark:   '#1a1a2e',
        cream:  '#fffdf7',
        bg:     '#ccc389',
      },
      backgroundImage: {
        'gradient-pink-purple': 'linear-gradient(135deg, #de18c7, #9b59b6)',
        'gradient-hero': 'linear-gradient(135deg, #fffdf7 0%, #f5e8ff 55%, #e8e0c0 100%)',
        'gradient-dark': 'linear-gradient(135deg, #05050f 0%, #0d0820 40%, #050d18 70%)',
      },
      boxShadow: {
        pink:   '0 8px 32px rgba(222, 24, 199, 0.15)',
        'pink-lg': '0 12px 28px rgba(222, 24, 199, 0.45)',
        card:   '0 4px 24px rgba(0, 0, 0, 0.07)',
        stripe: '0 6px 18px rgba(99, 91, 255, 0.35)',
      },
      borderRadius: {
        '2xl': '1.125rem',
        '3xl': '1.5rem',
      },
      animation: {
        'marquee':       'marquee-scroll var(--speed, 40s) linear infinite',
        'spin-slow':     'spin 3s linear infinite',
        'pulse-dot':     'pulse-dot 1.5s infinite',
        'ai-glow':       'ai-glow 2.5s ease-in-out infinite',
        'card-in':       'card-in 0.55s cubic-bezier(0.2, 0, 0.1, 1) forwards',
        'fade-in':       'fade-in 0.3s ease',
        'skel-pulse':    'skel-pulse 1.4s ease-in-out infinite',
        'bounce-dots':   'bounce-dots 0.8s infinite',
        'orb-1':         'orb-float-1 8s ease-in-out infinite alternate',
        'orb-2':         'orb-float-2 10s ease-in-out infinite alternate',
      },
      keyframes: {
        'pulse-dot':     { '0%,100%': { boxShadow: '0 0 0 0 rgba(46,204,113,0.4)' }, '50%': { boxShadow: '0 0 0 8px rgba(46,204,113,0)' } },
        'ai-glow':       { '0%,100%': { boxShadow: '0 0 10px rgba(168,85,247,0.4)' }, '50%': { boxShadow: '0 0 24px rgba(168,85,247,0.8),0 0 40px rgba(168,85,247,0.2)' } },
        'card-in':       { from: { opacity: '0', transform: 'translateY(22px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        'fade-in':       { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        'skel-pulse':    { '0%,100%': { opacity: '0.5' }, '50%': { opacity: '1' } },
        'bounce-dots':   { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-5px)' } },
        'marquee-scroll':{ from: { transform: 'translateX(0)' }, to: { transform: 'translateX(-50%)' } },
        'orb-float-1':   { from: { transform: 'translate(0,0)' }, to: { transform: 'translate(40px,30px)' } },
        'orb-float-2':   { from: { transform: 'translate(0,0)' }, to: { transform: 'translate(-30px,-40px)' } },
      },
    },
  },
  plugins: [
    require('tailwindcss-animate'),
  ],
}

export default config
