# ODRkart v2.0 – Full-Stack Next.js Application

India's premier Online Dispute Resolution platform, rebuilt on a modern production-ready stack.

---

## Tech Stack

| Layer       | Technology                          | Purpose                                  |
|-------------|-------------------------------------|------------------------------------------|
| Frontend    | **Next.js 14** (App Router)         | React server/client components, routing  |
| Styling     | **Tailwind CSS** + Framer Motion    | Design system, animations                |
| Backend     | **Next.js API Routes** (serverless) | REST endpoints, secure server logic      |
| Database    | **Supabase** (PostgreSQL)           | Auth, RLS, real-time subscriptions       |
| Auth        | **Supabase Auth**                   | Email/password + OAuth (Google/LinkedIn) |
| File Storage| **AWS S3** + presigned URLs         | Evidence upload (50MB max), direct-to-S3 |
| AI          | **Claude API** (server-only)        | Case analysis, blog generation, summaries|
| Payments    | **Stripe** (Payment Element)        | ₹1,999 filing fee, webhook handling      |
| Video       | **Agora RTC** (lazy-loaded)         | Encrypted live video hearings            |
| Hosting     | **Vercel** (edge functions)         | Next.js deployment, CDN, caching         |
| CDN/WAF     | **Cloudflare**                      | DDoS protection, cache, SSL              |

---

## Project Structure

```
odrkart/
├── app/
│   ├── api/
│   │   ├── ai/
│   │   │   ├── analyse/route.ts    # Claude case analysis (auth required)
│   │   │   ├── blog/route.ts       # AI blog generation (public)
│   │   │   └── summary/route.ts    # Platform summary (cached 10min)
│   │   ├── cases/route.ts          # Case CRUD
│   │   ├── payments/
│   │   │   ├── create-intent/route.ts  # Stripe PaymentIntent
│   │   │   └── webhook/route.ts        # Stripe webhook handler
│   │   ├── upload/route.ts         # S3 presigned URL generation
│   │   └── video/token/route.ts    # Agora RTC token
│   ├── auth/callback/route.ts      # OAuth callback
│   ├── dashboard/page.tsx          # User case dashboard
│   ├── file/page.tsx               # Multi-step case filing
│   ├── hearing/[id]/page.tsx       # Live video hearing room
│   ├── login/page.tsx              # Supabase email + OAuth login
│   ├── register/page.tsx           # New user registration
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx                    # Landing page
├── components/
│   ├── FileCase/
│   │   ├── AIAnalysisStep.tsx      # Calls /api/ai/analyse
│   │   ├── EvidenceUpload.tsx      # Dropzone + S3 direct upload
│   │   └── StripePaymentForm.tsx   # Stripe Payment Element
│   ├── Landing/
│   │   ├── AILabBlog.tsx           # Calls /api/ai/blog
│   │   ├── AIPill.tsx              # Calls /api/ai/summary
│   │   ├── Hero.tsx, About.tsx … (full landing sections)
│   ├── VideoHearing/
│   │   └── VideoHearing.tsx        # Agora RTC client (lazy loaded)
│   ├── ChatBot/ChatBot.tsx         # AI chatbot (calls /api/ai/chat)
│   └── ui/Navbar.tsx
├── hooks/
│   ├── useAuth.ts                  # Supabase auth state
│   └── useFileUpload.ts            # S3 upload with progress
├── lib/
│   ├── claude.ts                   # Anthropic SDK (server only)
│   ├── s3.ts                       # AWS S3 client (server only)
│   ├── stripe.ts                   # Stripe client (server only)
│   ├── agora.ts                    # Agora token generation (server only)
│   └── supabase.ts                 # Browser + server + admin clients
├── store/
│   └── caseStore.ts                # Zustand (case filing wizard state)
├── supabase/
│   └── migrations/001_initial_schema.sql
├── types/
│   └── database.ts                 # TypeScript types for DB schema
├── middleware.ts                   # Edge auth middleware
├── next.config.js
├── tailwind.config.ts
└── .env.example
```

---

## Security Architecture

### API Key Protection
- `ANTHROPIC_API_KEY`, `STRIPE_SECRET_KEY`, `AWS_SECRET_ACCESS_KEY`, `AGORA_APP_CERTIFICATE`, `SUPABASE_SERVICE_ROLE_KEY` — **server-only**, never in `NEXT_PUBLIC_` vars
- All AI calls go through `/api/ai/*` routes, never from the browser
- `NEXT_PUBLIC_` vars are limited to: Supabase URL, Supabase anon key, Stripe publishable key, Agora App ID

### Database Security
- Row Level Security (RLS) on all tables
- Users can only read/write their own cases
- `supabaseAdmin` (service role) only used in API routes

### File Upload
- Presigned S3 URLs expire in 5 minutes
- File type + size validated server-side before issuing URL
- AES-256 server-side encryption on all S3 objects

### Payments
- Payment amount is set server-side (never trusted from client)
- Stripe webhook signature verified via `constructWebhookEvent`
- Cases only activated after webhook confirms `payment_intent.succeeded`

---

## Local Development

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment variables
```bash
cp .env.example .env.local
# Fill in all values
```

### 3. Set up Supabase
```bash
npx supabase start           # local dev
npx supabase db push         # apply migrations
# OR paste SQL from supabase/migrations/ into Supabase Studio
```

### 4. Configure Stripe webhook (local)
```bash
stripe listen --forward-to localhost:3000/api/payments/webhook
# Copy the webhook secret to STRIPE_WEBHOOK_SECRET
```

### 5. Run dev server
```bash
npm run dev
# Open http://localhost:3000
```

---

## Deployment (Vercel + Cloudflare)

### Vercel
1. Connect GitHub repo to Vercel
2. Set all environment variables in **Vercel Dashboard → Settings → Environment Variables**
3. Set Framework Preset: **Next.js**
4. Deploy: `git push main`

### Stripe Webhook (Production)
1. Go to Stripe Dashboard → Webhooks → Add endpoint
2. URL: `https://odrkart.com/api/payments/webhook`
3. Events: `payment_intent.succeeded`, `payment_intent.payment_failed`
4. Copy webhook secret → `STRIPE_WEBHOOK_SECRET`

### Cloudflare
1. Proxy `odrkart.com` through Cloudflare (orange cloud)
2. Set SSL mode: **Full (strict)**
3. Enable: DDoS protection, Bot Fight Mode, WAF rules
4. Cache rules: cache `/api/ai/summary` for 10 minutes at edge

### Agora
1. Create a project at console.agora.io
2. Copy App ID → `NEXT_PUBLIC_AGORA_APP_ID`
3. Copy App Certificate → `AGORA_APP_CERTIFICATE`

### AWS S3
1. Create bucket `odrkart-evidence` in `ap-south-1`
2. Block public access ✓
3. Enable server-side encryption (AES-256) ✓
4. Create IAM user with `s3:PutObject`, `s3:GetObject`, `s3:DeleteObject`, `s3:HeadObject`
5. (Optional) Set up CloudFront distribution pointing to bucket

---

## Key Features

- ✅ **Multi-step case filing** with Zustand state persistence
- ✅ **AI Document Analyser** – dual Company + Client reports via Claude API (server-side)
- ✅ **AI Lab Blog** – auto-generates legal articles via Claude API (server-side)
- ✅ **AI Summary Pill** – cached platform summary (10min edge cache)
- ✅ **Stripe Payment Element** – supports cards, Apple Pay, Google Pay, UPI
- ✅ **Direct-to-S3 upload** with progress tracking (via presigned URLs)
- ✅ **Live video hearings** with Agora RTC (encrypted, lazy-loaded)
- ✅ **Supabase Auth** with RLS, OAuth (Google/LinkedIn), session cookies
- ✅ **Edge middleware** – auth protection with automatic redirects
- ✅ **Webhook-confirmed case activation** (no client-side payment trust)
- ✅ **Full TypeScript** with auto-generated database types
