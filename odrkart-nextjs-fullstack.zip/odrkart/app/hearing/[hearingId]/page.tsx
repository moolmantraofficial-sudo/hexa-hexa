// app/hearing/[hearingId]/page.tsx
'use client'

import { useParams, useRouter } from 'next/navigation'
import { useState } from 'react'
import { motion } from 'framer-motion'
import dynamic from 'next/dynamic'
import { ArrowLeft } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'

// Lazy-load Agora component (heavy SDK)
const VideoHearing = dynamic(
  () => import('@/components/VideoHearing/VideoHearing'),
  { ssr: false, loading: () => <HearingPlaceholder /> }
)

function HearingPlaceholder() {
  return (
    <div className="flex items-center justify-center h-full bg-[#07071a] rounded-2xl">
      <div className="text-center">
        <div className="w-12 h-12 rounded-full border-3 border-[#7c3aed]/30 border-t-[#a855f7] animate-spin mx-auto mb-4" />
        <p className="text-[#8b7aa8]">Loading hearing room…</p>
      </div>
    </div>
  )
}

export default function HearingPage() {
  const { hearingId } = useParams<{ hearingId: string }>()
  const router        = useRouter()
  const { user }      = useAuth()
  const [ended,        setEnded]       = useState(false)
  const [role]         = useState<'claimant' | 'respondent' | 'panelist'>('claimant') // resolved via case lookup

  if (ended) {
    return (
      <div className="min-h-screen bg-[#07071a] flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center text-3xl mx-auto mb-6">
            ✓
          </div>
          <h2 className="text-white text-2xl font-black mb-3">Hearing Ended</h2>
          <p className="text-[#8b7aa8] mb-8">
            Thank you for participating. Your session has been recorded and the panelist will issue the next steps shortly.
          </p>
          <button
            onClick={() => router.push('/dashboard')}
            className="bg-gradient-to-r from-[#7c3aed] to-[#de18c7] text-white px-8 py-3.5 rounded-full font-bold hover:-translate-y-0.5 transition-all"
          >
            Back to Dashboard
          </button>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#07071a] flex flex-col">
      {/* Mini top bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-[#8b7aa8] hover:text-white transition-colors text-sm"
        >
          <ArrowLeft size={16} /> Back
        </button>
        <div className="text-[#e0cfff] font-bold text-sm">ODRkart Secure Hearing Room</div>
        <div className="text-[#4a4a6a] text-xs">
          {user?.email?.split('@')[0]}
        </div>
      </div>

      {/* Main video area */}
      <div className="flex-1 p-4">
        <VideoHearing
          hearingId={hearingId}
          role={role}
          caseRef="Hearing"
          onEnd={() => setEnded(true)}
        />
      </div>
    </div>
  )
}
