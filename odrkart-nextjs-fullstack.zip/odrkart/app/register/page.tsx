// app/register/page.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Eye, EyeOff, Loader2 } from 'lucide-react'
import { createBrowserSupabase } from '@/lib/supabase'

const ACCOUNT_TYPES = ['Individual','Business','Law Firm','Mediator / Arbitrator']

export default function RegisterPage() {
  const supabase = createBrowserSupabase()
  const router   = useRouter()

  const [firstName,   setFirstName]   = useState('')
  const [lastName,    setLastName]    = useState('')
  const [email,       setEmail]       = useState('')
  const [password,    setPassword]    = useState('')
  const [accountType, setAccountType] = useState('Individual')
  const [showPass,    setShowPass]    = useState(false)
  const [loading,     setLoading]     = useState(false)
  const [error,       setError]       = useState<string | null>(null)

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password.length < 8) { setError('Password must be at least 8 characters'); return }
    setLoading(true)
    setError(null)

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name:    `${firstName} ${lastName}`.trim(),
          account_type: accountType.toLowerCase().replace(/ \/ /g, '_').replace(/ /g, '_'),
        },
      },
    })

    if (signUpError) { setError(signUpError.message); setLoading(false); return }

    // Create profile row
    if (data.user) {
      await supabase.from('profiles').upsert({
        id:           data.user.id,
        full_name:    `${firstName} ${lastName}`.trim(),
        account_type: accountType.toLowerCase().replace(/ \/ /g, '_').replace(/ /g, '_') as never,
      })
    }

    router.push('/dashboard')
  }

  const handleGoogleSignup = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback?next=/dashboard` },
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f8e8ff] to-[#f0edd6] flex items-center justify-center p-4 pt-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl w-full max-w-[490px] p-10 shadow-pink relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-pink to-purple" />

        <Link href="/" className="text-3xl font-black text-pink block mb-1">
          ODR<span className="text-dark">kart</span>
        </Link>
        <h2 className="text-2xl font-black text-dark mt-4">Create Your Account 🚀</h2>
        <p className="text-gray-400 text-sm mt-1 mb-7">Join 12,000+ users resolving disputes smarter</p>

        {/* Social auth */}
        <div className="flex gap-3 mb-5">
          <button
            onClick={handleGoogleSignup}
            className="flex-1 flex items-center justify-center gap-2 border-2 border-gray-200 rounded-xl py-3 text-sm font-semibold text-gray-600 hover:border-pink hover:text-pink transition-all"
          >
            🔵 Google
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 border-2 border-gray-200 rounded-xl py-3 text-sm font-semibold text-gray-600 hover:border-pink hover:text-pink transition-all">
            🔷 LinkedIn
          </button>
        </div>

        <div className="flex items-center gap-3 text-gray-300 text-xs mb-5">
          <span className="flex-1 h-px bg-gray-200" />or register with email<span className="flex-1 h-px bg-gray-200" />
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">First Name</label>
              <input
                type="text" value={firstName} onChange={e => setFirstName(e.target.value)}
                placeholder="First name" required
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">Last Name</label>
              <input
                type="text" value={lastName} onChange={e => setLastName(e.target.value)}
                placeholder="Last name" required
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Email</label>
            <input
              type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="Email address" required
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Account Type</label>
            <select
              value={accountType} onChange={e => setAccountType(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
            >
              {ACCOUNT_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Password</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                placeholder="Create a strong password (min 8 chars)" required minLength={8}
                className="w-full px-4 py-3 pr-11 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
              />
              <button type="button" onClick={() => setShowPass(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-pink">
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-red-600 text-sm">
              ⚠️ {error}
            </div>
          )}

          <button
            type="submit" disabled={loading}
            className="w-full py-3.5 mt-2 bg-pink text-white rounded-full font-bold text-sm shadow-[0_4px_14px_rgba(222,24,199,0.3)] hover:shadow-[0_8px_22px_rgba(222,24,199,0.4)] hover:-translate-y-0.5 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {loading ? <><Loader2 size={16} className="animate-spin" /> Creating account…</> : 'Create Free Account'}
          </button>
        </form>

        <p className="text-center text-gray-400 text-sm mt-5">
          Already have an account?{' '}
          <Link href="/login" className="text-pink font-semibold hover:underline">Login →</Link>
        </p>
        <p className="text-center mt-2">
          <Link href="/" className="text-gray-400 text-sm hover:text-pink transition-colors">← Back to Home</Link>
        </p>
      </motion.div>
    </div>
  )
}
