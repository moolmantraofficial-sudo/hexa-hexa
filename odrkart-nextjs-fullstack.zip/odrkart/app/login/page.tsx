// app/login/page.tsx
'use client'

import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Eye, EyeOff, Loader2 } from 'lucide-react'
import { createBrowserSupabase } from '@/lib/supabase'

export default function LoginPage() {
  const supabase    = createBrowserSupabase()
  const router      = useRouter()
  const searchParams= useSearchParams()
  const next        = searchParams.get('next') ?? '/dashboard'

  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState<string | null>(null)

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false) }
    else router.push(next)
  }

  const handleGoogleLogin = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback?next=${next}` },
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f8e8ff] to-[#f0edd6] flex items-center justify-center p-4 pt-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl w-full max-w-[470px] p-10 shadow-pink relative overflow-hidden"
      >
        {/* Top accent */}
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-pink to-purple" />

        <Link href="/" className="text-3xl font-black text-pink block mb-1">
          ODR<span className="text-dark">kart</span>
        </Link>
        <h2 className="text-2xl font-black text-dark mt-4">Welcome back 👋</h2>
        <p className="text-gray-400 text-sm mt-1 mb-7">Login to your ODRkart account</p>

        {/* Social auth */}
        <div className="flex gap-3 mb-5">
          <button
            onClick={handleGoogleLogin}
            className="flex-1 flex items-center justify-center gap-2 border-2 border-gray-200 rounded-xl py-3 text-sm font-semibold text-gray-600 hover:border-pink hover:text-pink transition-all"
          >
            🔵 Google
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 border-2 border-gray-200 rounded-xl py-3 text-sm font-semibold text-gray-600 hover:border-pink hover:text-pink transition-all">
            🔷 LinkedIn
          </button>
        </div>

        <div className="flex items-center gap-3 text-gray-300 text-xs mb-5">
          <span className="flex-1 h-px bg-gray-200" />or continue with email<span className="flex-1 h-px bg-gray-200" />
        </div>

        <form onSubmit={handleEmailLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none transition-all bg-gray-50 focus:border-pink focus:bg-white focus:shadow-[0_0_0_3px_rgba(222,24,199,0.1)]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Password</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                className="w-full px-4 py-3 pr-11 border-2 border-gray-200 rounded-xl text-sm outline-none transition-all bg-gray-50 focus:border-pink focus:bg-white focus:shadow-[0_0_0_3px_rgba(222,24,199,0.1)]"
              />
              <button
                type="button"
                onClick={() => setShowPass(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-pink transition-colors"
              >
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-red-600 text-sm">
              ⚠️ {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 mt-2 bg-pink text-white rounded-full font-bold text-sm shadow-[0_4px_14px_rgba(222,24,199,0.3)] hover:shadow-[0_8px_22px_rgba(222,24,199,0.4)] hover:-translate-y-0.5 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {loading ? <><Loader2 size={16} className="animate-spin" /> Logging in…</> : 'Login to Account'}
          </button>
        </form>

        <p className="text-center text-gray-400 text-sm mt-5">
          Don&apos;t have an account?{' '}
          <Link href="/register" className="text-pink font-semibold hover:underline">Register Free →</Link>
        </p>
        <p className="text-center mt-2">
          <Link href="/" className="text-gray-400 text-sm hover:text-pink transition-colors">← Back to Home</Link>
        </p>
      </motion.div>
    </div>
  )
}
