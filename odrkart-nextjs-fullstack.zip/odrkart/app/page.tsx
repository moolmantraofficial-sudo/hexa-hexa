// app/page.tsx
// Landing page – uses Next.js App Router.
// All interactive sections (AI Lab Blog, ChatBot, AI Panel) call
// backend API routes which securely hold the Anthropic key.

import type { Metadata } from 'next'
import Navbar from '@/components/ui/Navbar'
import LandingHero from '@/components/Landing/Hero'
import LandingAbout from '@/components/Landing/About'
import LandingServices from '@/components/Landing/Services'
import LandingRoadmap from '@/components/Landing/Roadmap'
import LandingJudges from '@/components/Landing/Judges'
import LandingStats from '@/components/Landing/Stats'
import LandingImpact from '@/components/Landing/Impact'
import LandingTestimonials from '@/components/Landing/Testimonials'
import LandingPartners from '@/components/Landing/Partners'
import LandingFAQ from '@/components/Landing/FAQ'
import LandingBlog from '@/components/Landing/Blog'
import AILabBlog from '@/components/Landing/AILabBlog'
import LandingContact from '@/components/Landing/Contact'
import LandingFooter from '@/components/Landing/Footer'
import AIPill from '@/components/Landing/AIPill'
import ChatBot from '@/components/ChatBot/ChatBot'

export const metadata: Metadata = {
  title: "ODRkart – India's Online Dispute Resolution Platform",
}

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <LandingHero />
        <LandingAbout />
        <LandingServices />
        <LandingRoadmap />
        <LandingJudges />
        <LandingStats />
        <LandingImpact />
        <LandingTestimonials />
        <LandingPartners />
        <LandingFAQ />
        <LandingBlog />
        <AILabBlog />
        <LandingContact />
      </main>
      <LandingFooter />
      {/* Floating interactive widgets */}
      <AIPill />
      <ChatBot />
    </>
  )
}
