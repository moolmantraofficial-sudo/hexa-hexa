// app/file/page.tsx
'use client'
/**
 * Multi-step case filing wizard.
 * Step 1–2: Form data → stored in Zustand + POST /api/cases
 * Step 3:   Evidence upload → presigned S3 PUT via useFileUpload hook
 * Step 4:   AI Analysis → POST /api/ai/analyse  (server holds API key)
 * Step 5:   Resolution preferences
 * Step 6:   Review + Stripe payment → POST /api/payments/create-intent
 */

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronRight, ChevronLeft, Home } from 'lucide-react'
import Navbar from '@/components/ui/Navbar'
import EvidenceUpload from '@/components/FileCase/EvidenceUpload'
import AIAnalysisStep from '@/components/FileCase/AIAnalysisStep'
import StripePaymentForm from '@/components/FileCase/StripePaymentForm'
import { useCaseStore } from '@/store/caseStore'

const STEPS = [
  { label: 'Case Info',   icon: '📋' },
  { label: 'Parties',     icon: '👤' },
  { label: 'Evidence',    icon: '📂' },
  { label: '✦ AI',       icon: '🧠' },
  { label: 'Resolution',  icon: '⚖️' },
  { label: 'Review',      icon: '✅' },
]

const CATEGORIES = ['Contract Dispute','Payment / Invoice','Consumer Complaint','Employment Matter','Real Estate / RERA','Intellectual Property','E-Commerce','Cross-Border Commercial']
const RES_TYPES  = ['mediation','arbitration','conciliation','unsure'] as const
const OUTCOMES   = ['Full monetary compensation','Partial refund or settlement','Specific performance of contract','Open to mediator\'s recommendation']
const LANGUAGES  = ['English','Hindi','Tamil','Telugu','Marathi','Bengali','Gujarati']

export default function FilePage() {
  const router    = useRouter()
  const store     = useCaseStore()
  const { currentStep: step, setStep, step1, step2, step5, files, caseId, caseRef, aiReport,
          setStep1, setStep2, setStep5, setCaseId, resetStore } = store

  const [saving,   setSaving]   = useState(false)
  const [stepError,setStepError]= useState<string | null>(null)
  const [success,  setSuccess]  = useState(false)
  const [paidId,   setPaidId]   = useState<string | null>(null)

  // ── Step progress bar ────────────────────────────────────────────────────────
  const prog = `${(step / (STEPS.length - 1)) * 100}%`

  // ── Create/update case in DB ─────────────────────────────────────────────────
  const upsertCase = async (): Promise<string | null> => {
    if (caseId) return caseId   // already created
    setSaving(true)
    try {
      const res = await fetch('/api/cases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title:              step1.title,
          category:           step1.category,
          claim_amount:       step1.claimAmount ? Number(step1.claimAmount) : undefined,
          resolution_type:    step1.resolutionType || 'unsure',
          description:        step1.description,
          respondent_name:    step2.respondentName,
          respondent_email:   step2.respondentEmail || undefined,
          hearing_preference: step5.hearingPreference,
          language_preference:step5.languagePreference.toLowerCase(),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? 'Failed to save case')
      setCaseId(data.caseId, data.caseRef)
      return data.caseId
    } catch (e: unknown) {
      setStepError(e instanceof Error ? e.message : 'Failed to save')
      return null
    } finally {
      setSaving(false)
    }
  }

  const nextStep = async (to: number) => {
    setStepError(null)
    // Validate before advancing
    if (step === 0) {
      if (!step1.title || !step1.category || !step1.description || !step1.resolutionType)
        return setStepError('Please fill in all required fields.')
    }
    if (step === 1) {
      if (!step2.claimantName || !step2.claimantEmail || !step2.respondentName)
        return setStepError('Please fill in all required fields.')
      // Create case in DB now (before evidence upload)
      if (!caseId) { const id = await upsertCase(); if (!id) return }
    }
    setStep(to)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handlePaymentSuccess = (intentId: string) => {
    setPaidId(intentId)
    setSuccess(true)
    resetStore()
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#f5f5ff] to-[#f8f4e8] flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-3xl p-10 max-w-lg w-full text-center shadow-pink"
        >
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center text-3xl mx-auto mb-6">✓</div>
          <h2 className="text-2xl font-black text-dark mb-2">Case Filed Successfully!</h2>
          <p className="text-gray-400 text-sm mb-4">Your Case Reference ID:</p>
          <div className="bg-gradient-to-br from-pink/8 to-purple/8 border border-pink/25 rounded-2xl px-6 py-4 inline-block mb-2">
            <strong className="text-2xl font-mono text-pink">{caseRef ?? 'ODR-2026-XXXX'}</strong>
          </div>
          {paidId && <p className="text-purple-deep text-xs font-semibold mt-2">Payment: {paidId}</p>}
          <p className="text-gray-400 text-sm mt-4 mb-8">Our team will review your case and assign a panelist within 24 hours.</p>
          <div className="flex gap-4 justify-center flex-wrap">
            <button onClick={() => router.push('/dashboard')} className="bg-pink text-white px-6 py-3 rounded-full font-bold shadow-pink hover:-translate-y-0.5 transition-all">
              View Dashboard
            </button>
            <button onClick={() => router.push('/')} className="border-2 border-pink text-pink px-6 py-3 rounded-full font-bold hover:bg-pink/5 transition-all">
              Back to Home
            </button>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f5f5ff] to-[#f8f4e8]">
      <Navbar />
      <div className="max-w-[960px] mx-auto px-5 pt-24 pb-16">
        <h1 className="text-3xl font-black text-dark mb-1">
          File a <span className="text-pink">New Dispute</span>
        </h1>
        <p className="text-gray-400 mb-8 text-sm">Complete all steps — takes less than 5 minutes.</p>

        {/* Step bar */}
        <div className="relative flex justify-between mb-10">
          {/* Progress track */}
          <div className="absolute top-5 left-[4%] w-[92%] h-0.5 bg-gray-200 z-0" />
          <div className="absolute top-5 left-[4%] h-0.5 bg-gradient-to-r from-pink to-purple z-0 transition-all duration-500" style={{ width: prog }} />
          {STEPS.map((s, i) => (
            <div key={i} className="flex flex-col items-center gap-1.5 relative z-10">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all ${
                i < step  ? 'bg-gradient-to-br from-pink to-purple text-white shadow-pink' :
                i === step ? 'bg-gradient-to-br from-pink to-purple text-white shadow-pink scale-110' :
                'bg-gray-200 text-gray-400'
              }`}>
                {i < step ? '✓' : i === 3 ? '✦' : i + 1}
              </div>
              <span className={`text-xs font-semibold hidden sm:block ${i <= step ? 'text-pink' : 'text-gray-400'}`}>{s.label}</span>
            </div>
          ))}
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl p-8 shadow-pink">
          <AnimatePresence mode="wait">
            {/* ── Step 1: Case Info ── */}
            {step === 0 && (
              <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <h3 className="text-xl font-black text-dark mb-1">Step 1 – Case Information</h3>
                <p className="text-gray-400 text-sm mb-6">Provide basic details about your dispute.</p>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Case Title *</label>
                    <input
                      value={step1.title} onChange={e => setStep1({ title: e.target.value })}
                      placeholder="e.g. Unpaid invoice – ABC Pvt. Ltd."
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-1.5">Dispute Category *</label>
                      <select
                        value={step1.category} onChange={e => setStep1({ category: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
                      >
                        <option value="">Select category</option>
                        {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-1.5">Claim Amount (₹)</label>
                      <input
                        type="number" value={step1.claimAmount} onChange={e => setStep1({ claimAmount: e.target.value })}
                        placeholder="e.g. 500000"
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Preferred Resolution *</label>
                    <select
                      value={step1.resolutionType} onChange={e => setStep1({ resolutionType: e.target.value as never })}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all"
                    >
                      <option value="">Select resolution type</option>
                      {RES_TYPES.map(r => <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Brief Description *</label>
                    <textarea
                      value={step1.description} onChange={e => setStep1({ description: e.target.value })}
                      placeholder="Describe what happened, when, and the key facts…"
                      rows={4}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all resize-vertical"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* ── Step 2: Parties ── */}
            {step === 1 && (
              <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <h3 className="text-xl font-black text-dark mb-1">Step 2 – Parties Involved</h3>
                <p className="text-gray-400 text-sm mb-6">Tell us who is involved in this dispute.</p>
                <h4 className="text-pink font-bold text-sm mb-3">👤 Claimant (You)</h4>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Full Name *</label>
                    <input value={step2.claimantName} onChange={e => setStep2({ claimantName: e.target.value })} placeholder="Your legal name" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Email *</label>
                    <input type="email" value={step2.claimantEmail} onChange={e => setStep2({ claimantEmail: e.target.value })} placeholder="Your email" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all" />
                  </div>
                </div>
                <hr className="border-dashed border-gray-200 my-4" />
                <h4 className="text-purple font-bold text-sm mb-3">⚖️ Respondent</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Full Name / Company *</label>
                    <input value={step2.respondentName} onChange={e => setStep2({ respondentName: e.target.value })} placeholder="Respondent name" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Email (if known)</label>
                    <input type="email" value={step2.respondentEmail} onChange={e => setStep2({ respondentEmail: e.target.value })} placeholder="Their email" className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all" />
                  </div>
                </div>
              </motion.div>
            )}

            {/* ── Step 3: Evidence ── */}
            {step === 2 && (
              <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <h3 className="text-xl font-black text-dark mb-1">Step 3 – Upload Evidence</h3>
                <p className="text-gray-400 text-sm mb-6">Upload contracts, invoices, screenshots, or other supporting documents.</p>
                <EvidenceUpload caseId={caseId ?? ''} />
              </motion.div>
            )}

            {/* ── Step 4: AI Analysis ── */}
            {step === 3 && (
              <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <h3 className="text-xl font-black text-dark mb-1">Step 4 – AI Analysis</h3>
                <p className="text-gray-400 text-sm mb-6">Our AI reviews your case and generates dual reports.</p>
                <AIAnalysisStep onComplete={() => nextStep(4)} />
              </motion.div>
            )}

            {/* ── Step 5: Resolution Prefs ── */}
            {step === 4 && (
              <motion.div key="s4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <h3 className="text-xl font-black text-dark mb-1">Step 5 – Resolution Preferences</h3>
                <p className="text-gray-400 text-sm mb-6">Tell us how you'd like to proceed.</p>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Desired Outcome</label>
                    <select value={step5.desiredOutcome} onChange={e => setStep5({ desiredOutcome: e.target.value })} className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all">
                      {OUTCOMES.map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Hearing Preference</label>
                    <select value={step5.hearingPreference} onChange={e => setStep5({ hearingPreference: e.target.value as never })} className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all">
                      <option value="video">Video call (online hearing)</option>
                      <option value="async">Asynchronous (written only)</option>
                      <option value="in_person">In-person</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1.5">Language Preference</label>
                    <select value={step5.languagePreference} onChange={e => setStep5({ languagePreference: e.target.value })} className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm outline-none bg-gray-50 focus:border-pink focus:bg-white transition-all">
                      {LANGUAGES.map(l => <option key={l}>{l}</option>)}
                    </select>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ── Step 6: Review + Pay ── */}
            {step === 5 && (
              <motion.div key="s5" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <h3 className="text-xl font-black text-dark mb-1">Step 6 – Review &amp; Submit</h3>
                <p className="text-gray-400 text-sm mb-6">Confirm your details and complete payment to file your case.</p>

                {/* Summary */}
                <div className="bg-gray-50 rounded-2xl p-5 mb-6 space-y-3">
                  {[
                    ['Case Title',   step1.title],
                    ['Category',     step1.category],
                    ['Claim Amount', step1.claimAmount ? `₹${Number(step1.claimAmount).toLocaleString('en-IN')}` : '—'],
                    ['AI Analysis',  aiReport ? '✦ Completed' : '⚠️ Not run'],
                    ['Evidence',     `${files.length} document${files.length !== 1 ? 's' : ''} uploaded`],
                    ['Platform Fee', '₹1,999 (incl. GST)'],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between text-sm py-2 border-b border-gray-100 last:border-0">
                      <span className="font-semibold text-dark">{k}</span>
                      <span className={`${k === 'Platform Fee' ? 'text-pink font-bold' : k === 'AI Analysis' ? 'text-purple-deep font-semibold' : 'text-gray-500'}`}>{v}</span>
                    </div>
                  ))}
                </div>

                {/* Stripe */}
                {caseId && <StripePaymentForm caseId={caseId} onSuccess={handlePaymentSuccess} />}
                {!caseId && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-700 text-sm text-center">
                    ⚠️ Case not yet saved. Go back and ensure all steps are complete.
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Error */}
          {stepError && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-red-600 text-sm">
              ⚠️ {stepError}
            </div>
          )}

          {/* Nav buttons */}
          {step < 5 && (
            <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
              <button
                onClick={() => step === 0 ? router.push('/') : nextStep(step - 1)}
                className="flex items-center gap-2 bg-gray-100 text-gray-600 px-5 py-2.5 rounded-full font-semibold text-sm hover:bg-gray-200 transition-all"
              >
                {step === 0 ? <><Home size={15} /> Home</> : <><ChevronLeft size={15} /> Back</>}
              </button>
              {step !== 3 && (
                <button
                  onClick={() => nextStep(step + 1)}
                  disabled={saving}
                  className="flex items-center gap-2 bg-pink text-white px-6 py-2.5 rounded-full font-bold text-sm shadow-pink hover:-translate-y-0.5 transition-all disabled:opacity-60"
                >
                  {saving ? 'Saving…' : <>Next <ChevronRight size={15} /></>}
                </button>
              )}
            </div>
          )}
          {step === 5 && (
            <div className="flex justify-start mt-6 pt-4 border-t border-gray-100">
              <button onClick={() => nextStep(4)} className="flex items-center gap-2 bg-gray-100 text-gray-600 px-5 py-2.5 rounded-full font-semibold text-sm hover:bg-gray-200 transition-all">
                <ChevronLeft size={15} /> Back
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
