// app/layout.tsx
import type { Metadata, Viewport } from 'next'
import { DM_Sans, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})
const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
  weight: ['700', '800'],
})

export const metadata: Metadata = {
  title: { default: 'ODRkart – Online Dispute Resolution India', template: '%s | ODRkart' },
  description: "India's premier ODR platform. Resolve commercial, consumer and contractual disputes online with certified arbitrators and mediators.",
  keywords: ['ODR', 'online dispute resolution', 'arbitration', 'mediation', 'India', 'legal', 'settlement'],
  authors: [{ name: 'ODRkart', url: 'https://odrkart.com' }],
  creator: 'ODRkart',
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? 'https://odrkart.com'),
  openGraph: {
    type:        'website',
    locale:      'en_IN',
    url:         'https://odrkart.com',
    title:       'ODRkart – Online Dispute Resolution India',
    description: "Resolve disputes faster, smarter. 12K+ cases. 30-day avg resolution.",
    siteName:    'ODRkart',
  },
  twitter: {
    card:    'summary_large_image',
    title:   'ODRkart – Online Dispute Resolution India',
    creator: '@odrkart',
  },
  robots: { index: true, follow: true },
}

export const viewport: Viewport = {
  width:        'device-width',
  initialScale: 1,
  themeColor:   '#de18c7',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${dmSans.variable} ${jetbrainsMono.variable}`}>
      <body className="font-sans antialiased bg-background text-foreground">
        {children}
      </body>
    </html>
  )
}
