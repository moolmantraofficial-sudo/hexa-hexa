// app/api/video/token/route.ts
// POST /api/video/token
// Returns an Agora RTC token for the authenticated user to join a hearing.
// Auth required. Validates hearing access.

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabase, supabaseAdmin } from '@/lib/supabase'
import { generateAgoraToken, buildChannelName, roleToUid } from '@/lib/agora'
import { z } from 'zod'

const Schema = z.object({
  hearingId: z.string().uuid(),
  role:      z.enum(['claimant','respondent','panelist','observer']).default('claimant'),
})

export async function POST(req: NextRequest) {
  // ── Auth ────────────────────────────────────────────────────────────────────
  const supabase = createServerSupabase()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { hearingId, role } = Schema.parse(await req.json())

  // ── Verify user has access to this hearing ──────────────────────────────────
  const { data: hearing } = await supabaseAdmin
    .from('hearings')
    .select('id, channel_name, case_id, status, cases(claimant_id, panelist_id)')
    .eq('id', hearingId)
    .single()

  if (!hearing) return NextResponse.json({ error: 'Hearing not found' }, { status: 404 })
  if (hearing.status === 'cancelled') return NextResponse.json({ error: 'Hearing cancelled' }, { status: 410 })

  // Validate the user has the claimed role
  const caseRow = hearing.cases as { claimant_id: string; panelist_id: string } | null
  const isClaimant = caseRow?.claimant_id === session.user.id
  const isPanelist = caseRow?.panelist_id === session.user.id
  if (!isClaimant && !isPanelist)
    return NextResponse.json({ error: 'Access denied' }, { status: 403 })

  const actualRole = isPanelist ? 'panelist' : role
  const channel    = hearing.channel_name || buildChannelName(hearingId)
  const uid        = roleToUid(actualRole as 'claimant' | 'panelist', 0)
  const tokenData  = generateAgoraToken(channel, uid, 'host')

  // ── Mark hearing as live if not already ────────────────────────────────────
  if (hearing.status === 'scheduled') {
    await supabaseAdmin
      .from('hearings')
      .update({ status: 'live', started_at: new Date().toISOString() })
      .eq('id', hearingId)
  }

  return NextResponse.json({
    ...tokenData,
    role:      actualRole,
    hearingId,
  })
}
