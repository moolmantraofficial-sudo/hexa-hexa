// app/api/ai/blog/route.ts
// POST /api/ai/blog
// Generates AI blog posts, optionally persists to DB.
// Public route (no auth required for landing page AI Lab).

import { NextRequest, NextResponse } from 'next/server'
import { generateBlogPosts } from '@/lib/claude'
import { supabaseAdmin } from '@/lib/supabase'
import { z } from 'zod'

const LAB_TOPICS: Record<string, string[]> = {
  arbitration:  [
    'The Future of Arbitrator Selection in AI-Powered ODR Systems',
    'How Real-Time Transcription is Changing Online Arbitral Hearings',
    'Doctrine of Kompetenz-Kompetenz in the Age of Digital Arbitration',
  ],
  technology: [
    'Large Language Models as Legal Research Tools: Opportunities and Risks',
    'Smart Contracts and Self-Executing Dispute Clauses: A 2026 Analysis',
    'Deepfake Evidence in Arbitration: Detection, Admissibility and Safeguards',
  ],
  consumer: [
    'The Psychology of Online Dispute Resolution: Why Parties Settle Faster',
    'Consumer Protection Act 2019: Gaps That ODR Platforms Fill',
    'E-Commerce Return Fraud and the ODR Response Framework',
  ],
  international: [
    'UNCITRAL Model Law 2.0: What Changes Mean for Indian Practitioners',
    'Belt and Road Disputes: How Indian Firms Can Leverage ODR',
    'Cross-Border Insolvency and ADR: The New Frontier',
  ],
  all: [
    'Generative AI in ODR: From Document Drafting to Award Generation',
    'The Ethical Arbitrator in the Age of Algorithmic Justice',
    'Carbon Credits and Dispute Resolution: Emerging Practice Areas',
    'How Tokenized Assets Are Creating New Classes of Commercial Disputes',
    'ODR Accessibility: Bridging the Digital Divide in Rural India',
  ],
}

const BodySchema = z.object({
  topic:   z.enum(['all', 'arbitration', 'technology', 'consumer', 'international']).default('all'),
  count:   z.number().int().min(1).max(6).default(4),
  persist: z.boolean().default(false),  // save to DB
})

export async function POST(req: NextRequest) {
  let body: z.infer<typeof BodySchema>
  try { body = BodySchema.parse(await req.json()) }
  catch { body = { topic: 'all', count: 4, persist: false } }

  const pool  = [...(LAB_TOPICS[body.topic] ?? LAB_TOPICS.all), ...LAB_TOPICS.all]
  const shuffled = pool.sort(() => Math.random() - .5).slice(0, body.count)

  let posts
  try {
    posts = await generateBlogPosts(shuffled, body.count)
  } catch (e: unknown) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'AI failed' }, { status: 502 })
  }

  // Optionally persist to Supabase
  if (body.persist && posts.length > 0) {
    await supabaseAdmin.from('blog_posts').insert(
      posts.map(p => ({
        title:    p.title,
        excerpt:  p.excerpt,
        category: p.category,
        emoji:    p.emoji,
        author:   p.author,
        read_time: p.readTime,
        topic_tag: body.topic,
      }))
    )
  }

  return NextResponse.json({ posts, generatedAt: new Date().toISOString() })
}
