// app/api/ai/analyse/route.ts
// POST /api/ai/analyse
// Accepts case context, calls Claude (server side), saves to DB, returns reports.
// Authentication required.

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabase, supabaseAdmin } from '@/lib/supabase'
import { generateCompanyReport, generateClientReport, type CaseContext } from '@/lib/claude'
import { z } from 'zod'

const BodySchema = z.object({
  caseId:      z.string().uuid(),
  title:       z.string().min(1),
  category:    z.string().min(1),
  amount:      z.string(),
  resolution:  z.string(),
  description: z.string(),
  claimant:    z.string(),
  respondent:  z.string(),
  documents:   z.string(),
})

export async function POST(req: NextRequest) {
  // ── Auth check ──────────────────────────────────────────────────────────────
  const supabase = createServerSupabase()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  // ── Validate body ───────────────────────────────────────────────────────────
  let body: z.infer<typeof BodySchema>
  try {
    body = BodySchema.parse(await req.json())
  } catch (e: unknown) {
    return NextResponse.json({ error: 'Invalid request', details: e }, { status: 400 })
  }

  // ── Verify case belongs to this user ────────────────────────────────────────
  const { data: caseRow } = await supabaseAdmin
    .from('cases')
    .select('id')
    .eq('id', body.caseId)
    .eq('claimant_id', session.user.id)
    .single()

  if (!caseRow) return NextResponse.json({ error: 'Case not found' }, { status: 404 })

  // ── Build context ───────────────────────────────────────────────────────────
  const ctx: CaseContext = {
    ...body,
    date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }),
  }

  // ── Call Claude (parallel) ──────────────────────────────────────────────────
  let companyReport = '', clientReport = '', error: string | null = null
  try {
    ;[companyReport, clientReport] = await Promise.all([
      generateCompanyReport(ctx),
      generateClientReport(ctx),
    ])
  } catch (e: unknown) {
    error = e instanceof Error ? e.message : 'AI generation failed'
    return NextResponse.json({ error }, { status: 502 })
  }

  // ── Derive merit score ──────────────────────────────────────────────────────
  const lower = companyReport.toLowerCase()
  const legalMerit = lower.includes('strong') || lower.includes('high merit') ? 87
                   : lower.includes('weak')   || lower.includes('low merit')  ? 42
                   : 65
  const riskLevel  = lower.includes('high risk') ? 'high' : lower.includes('low risk') ? 'low' : 'medium'

  // ── Persist to DB ───────────────────────────────────────────────────────────
  await supabaseAdmin
    .from('ai_reports')
    .upsert({
      case_id:        body.caseId,
      company_report: companyReport,
      client_report:  clientReport,
      legal_merit:    legalMerit,
      risk_level:     riskLevel,
    }, { onConflict: 'case_id' })

  return NextResponse.json({
    companyReport,
    clientReport,
    legalMerit,
    riskLevel,
    generatedAt: new Date().toISOString(),
  })
}
