// app/api/upload/route.ts
// POST /api/upload
// Returns a presigned S3 PUT URL so the browser can upload directly to S3.
// Auth required. Validates file type/size before issuing URL.

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabase, supabaseAdmin } from '@/lib/supabase'
import { getPresignedUploadUrl, buildS3Key, ALLOWED_MIME_TYPES, MAX_FILE_SIZE_BYTES } from '@/lib/s3'
import { z } from 'zod'

const Schema = z.object({
  caseId:   z.string().uuid(),
  fileName: z.string().min(1).max(255),
  mimeType: z.string(),
  fileSize: z.number().positive(),
  docType:  z.enum(['evidence','contract','agreement','invoice','other']).default('evidence'),
})

export async function POST(req: NextRequest) {
  // ── Auth ────────────────────────────────────────────────────────────────────
  const supabase = createServerSupabase()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  let body: z.infer<typeof Schema>
  try { body = Schema.parse(await req.json()) }
  catch (e) { return NextResponse.json({ error: 'Invalid input', details: e }, { status: 400 }) }

  // ── Validate ────────────────────────────────────────────────────────────────
  if (!ALLOWED_MIME_TYPES.includes(body.mimeType))
    return NextResponse.json({ error: 'File type not allowed' }, { status: 415 })

  if (body.fileSize > MAX_FILE_SIZE_BYTES)
    return NextResponse.json({ error: 'File exceeds 50 MB limit' }, { status: 413 })

  // ── Ensure case belongs to user ─────────────────────────────────────────────
  const { data: caseRow } = await supabaseAdmin
    .from('cases')
    .select('id')
    .eq('id', body.caseId)
    .eq('claimant_id', session.user.id)
    .single()
  if (!caseRow) return NextResponse.json({ error: 'Case not found' }, { status: 404 })

  // ── Build S3 key with sanitized filename ────────────────────────────────────
  const safeFilename = `${Date.now()}_${body.fileName.replace(/[^a-zA-Z0-9._-]/g, '_')}`
  const s3Key = buildS3Key('evidence', body.caseId, safeFilename)

  // ── Issue presigned URL ─────────────────────────────────────────────────────
  const uploadUrl = await getPresignedUploadUrl(s3Key, body.mimeType)

  // ── Record document metadata in DB ─────────────────────────────────────────
  const { data: doc, error } = await supabaseAdmin
    .from('case_documents')
    .insert({
      case_id:     body.caseId,
      uploader_id: session.user.id,
      file_name:   body.fileName,
      s3_key:      s3Key,
      file_size:   body.fileSize,
      mime_type:   body.mimeType,
      doc_type:    body.docType,
    })
    .select('id')
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({
    uploadUrl,       // browser PUTs directly here
    s3Key,
    documentId: doc.id,
    expiresIn: 300,
  })
}
