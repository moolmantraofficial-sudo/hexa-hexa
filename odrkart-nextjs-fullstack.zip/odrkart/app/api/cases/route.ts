// app/api/cases/route.ts
// GET  /api/cases         → list user's cases
// POST /api/cases         → create draft case
// PATCH /api/cases/[id]   → update case (separate file)

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabase, supabaseAdmin } from '@/lib/supabase'
import { z } from 'zod'

const CreateCaseSchema = z.object({
  title:              z.string().min(3),
  category:           z.string().min(1),
  claim_amount:       z.number().positive().optional(),
  resolution_type:    z.enum(['mediation','arbitration','conciliation','unsure']),
  description:        z.string().min(10),
  respondent_name:    z.string().min(1),
  respondent_email:   z.string().email().optional(),
  hearing_preference: z.enum(['video','async','in_person']).default('video'),
  language_preference:z.string().default('english'),
})

// GET – list current user's cases
export async function GET(req: NextRequest) {
  const supabase = createServerSupabase()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')

  let query = supabaseAdmin
    .from('cases')
    .select(`
      id, case_ref, title, category, claim_amount, status,
      resolution_type, filed_at, resolved_at, created_at,
      respondent_name, panelist_id,
      ai_reports(legal_merit, risk_level)
    `)
    .eq('claimant_id', session.user.id)
    .order('created_at', { ascending: false })

  if (status) query = query.eq('status', status)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ cases: data })
}

// POST – create a draft case
export async function POST(req: NextRequest) {
  const supabase = createServerSupabase()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  let body: z.infer<typeof CreateCaseSchema>
  try { body = CreateCaseSchema.parse(await req.json()) }
  catch (e) { return NextResponse.json({ error: 'Validation failed', details: e }, { status: 400 }) }

  const { data, error } = await supabaseAdmin
    .from('cases')
    .insert({ ...body, claimant_id: session.user.id, status: 'draft' })
    .select('id, case_ref')
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ caseId: data.id, caseRef: data.case_ref }, { status: 201 })
}
