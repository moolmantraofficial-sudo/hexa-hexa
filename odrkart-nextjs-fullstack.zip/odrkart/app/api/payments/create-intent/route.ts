// app/api/payments/create-intent/route.ts
// POST /api/payments/create-intent
// Creates a Stripe PaymentIntent for case filing fee. Auth required.

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabase, supabaseAdmin } from '@/lib/supabase'
import { createCaseFilingIntent } from '@/lib/stripe'
import { z } from 'zod'

const Schema = z.object({
  caseId: z.string().uuid(),
})

export async function POST(req: NextRequest) {
  // ── Auth ────────────────────────────────────────────────────────────────────
  const supabase = createServerSupabase()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { caseId } = Schema.parse(await req.json())

  // ── Load case ───────────────────────────────────────────────────────────────
  const { data: caseRow } = await supabaseAdmin
    .from('cases')
    .select('id, title, status')
    .eq('id', caseId)
    .eq('claimant_id', session.user.id)
    .single()

  if (!caseRow) return NextResponse.json({ error: 'Case not found' }, { status: 404 })
  if (caseRow.status !== 'draft') return NextResponse.json({ error: 'Case already submitted' }, { status: 400 })

  // ── Create PaymentIntent ────────────────────────────────────────────────────
  const intent = await createCaseFilingIntent(caseId, caseRow.title, session.user.email ?? '')

  // ── Save intent ID to case ──────────────────────────────────────────────────
  await supabaseAdmin
    .from('cases')
    .update({ payment_intent: intent.id })
    .eq('id', caseId)

  return NextResponse.json({
    clientSecret: intent.client_secret,
    intentId:     intent.id,
    amount:       intent.amount,
    currency:     intent.currency,
  })
}
