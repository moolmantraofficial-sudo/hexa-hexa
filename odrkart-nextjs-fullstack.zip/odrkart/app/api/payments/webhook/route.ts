// app/api/payments/webhook/route.ts
// POST /api/payments/webhook
// Receives Stripe events, activates cases on payment success.
// No auth – validated by Stripe signature.

import { NextRequest, NextResponse } from 'next/server'
import { constructWebhookEvent } from '@/lib/stripe'
import { supabaseAdmin } from '@/lib/supabase'
import type Stripe from 'stripe'

export const config = { api: { bodyParser: false } }

export async function POST(req: NextRequest) {
  const body = Buffer.from(await req.arrayBuffer())
  const sig  = req.headers.get('stripe-signature')!

  let event: Stripe.Event
  try {
    event = constructWebhookEvent(body, sig)
  } catch (e: unknown) {
    console.error('⚠️  Stripe webhook signature verification failed:', e)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const intent = event.data.object as Stripe.PaymentIntent
      const caseId = intent.metadata.caseId

      // Mark case as filed
      const { error } = await supabaseAdmin
        .from('cases')
        .update({
          status:   'filed',
          paid_at:  new Date().toISOString(),
          filed_at: new Date().toISOString(),
        })
        .eq('id', caseId)
        .eq('payment_intent', intent.id)

      if (error) {
        console.error('❌ Failed to activate case', caseId, error)
        return NextResponse.json({ error: 'DB update failed' }, { status: 500 })
      }

      console.log('✅ Case filed after payment:', caseId, intent.id)
      break
    }

    case 'payment_intent.payment_failed': {
      const intent = event.data.object as Stripe.PaymentIntent
      console.warn('⚠️ Payment failed for case:', intent.metadata.caseId)
      // Could notify user via Resend/email here
      break
    }

    default:
      // Unhandled event type – ignore
  }

  return NextResponse.json({ received: true })
}
