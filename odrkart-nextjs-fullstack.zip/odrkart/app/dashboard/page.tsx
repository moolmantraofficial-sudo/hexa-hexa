// app/dashboard/page.tsx
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Plus, Scale, Clock, CheckCircle, AlertCircle, Video, FileText, BarChart3 } from 'lucide-react'
import Navbar from '@/components/ui/Navbar'
import { useAuth } from '@/hooks/useAuth'
import type { Case } from '@/types/database'

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; icon: React.ReactNode }> = {
  draft:    { label: 'Draft',     color: 'text-gray-500',  bg: 'bg-gray-100',     icon: <FileText size={12} /> },
  filed:    { label: 'Filed',     color: 'text-blue-600',  bg: 'bg-blue-50',      icon: <Clock size={12} /> },
  review:   { label: 'In Review', color: 'text-amber-600', bg: 'bg-amber-50',     icon: <AlertCircle size={12} /> },
  assigned: { label: 'Assigned',  color: 'text-purple-600',bg: 'bg-purple-50',    icon: <Scale size={12} /> },
  hearing:  { label: 'Hearing',   color: 'text-pink',      bg: 'bg-pink-light',   icon: <Video size={12} /> },
  resolved: { label: 'Resolved',  color: 'text-green-600', bg: 'bg-green-50',     icon: <CheckCircle size={12} /> },
  closed:   { label: 'Closed',    color: 'text-gray-400',  bg: 'bg-gray-50',      icon: <CheckCircle size={12} /> },
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [cases,   setCases]   = useState<Case[]>([])
  const [loading, setLoading] = useState(true)
  const [filter,  setFilter]  = useState<string>('all')

  useEffect(() => {
    fetch('/api/cases')
      .then(r => r.json())
      .then(d => { setCases(d.cases ?? []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const filtered = filter === 'all' ? cases : cases.filter(c => c.status === filter)

  const stats = {
    total:    cases.length,
    active:   cases.filter(c => ['filed','review','assigned','hearing'].includes(c.status)).length,
    resolved: cases.filter(c => c.status === 'resolved').length,
    draft:    cases.filter(c => c.status === 'draft').length,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-6 pt-24 pb-16">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black text-dark">My Cases</h1>
            <p className="text-gray-400 mt-1">Welcome back, {user?.email?.split('@')[0]}</p>
          </div>
          <Link
            href="/file"
            className="flex items-center gap-2 bg-pink text-white px-5 py-3 rounded-full font-bold text-sm shadow-pink hover:-translate-y-0.5 hover:shadow-pink-lg transition-all"
          >
            <Plus size={16} /> File New Case
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Cases',    value: stats.total,    icon: '📁', color: 'text-dark' },
            { label: 'Active Cases',   value: stats.active,   icon: '⚡', color: 'text-blue-600' },
            { label: 'Resolved',       value: stats.resolved, icon: '✅', color: 'text-green-600' },
            { label: 'Drafts',         value: stats.draft,    icon: '📝', color: 'text-amber-600' },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className="bg-white rounded-2xl p-5 shadow-card border border-gray-100"
            >
              <div className="text-2xl mb-2">{s.icon}</div>
              <div className={`text-2xl font-black font-mono ${s.color}`}>{s.value}</div>
              <div className="text-gray-400 text-sm mt-1">{s.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2 flex-wrap mb-6">
          {['all', 'draft', 'filed', 'hearing', 'resolved'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-all capitalize ${
                filter === f
                  ? 'bg-pink text-white shadow-pink'
                  : 'bg-white text-gray-500 border border-gray-200 hover:border-pink hover:text-pink'
              }`}
            >
              {f === 'all' ? '📋 All' : f}
            </button>
          ))}
        </div>

        {/* Cases list */}
        {loading ? (
          <div className="flex justify-center py-16">
            <div className="w-10 h-10 rounded-full border-3 border-pink/20 border-t-pink animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">⚖️</div>
            <h3 className="text-dark font-bold text-lg">No cases {filter !== 'all' ? `with status "${filter}"` : 'yet'}</h3>
            <p className="text-gray-400 text-sm mt-2 mb-6">File your first dispute to get started.</p>
            <Link href="/file" className="bg-pink text-white px-6 py-3 rounded-full font-bold text-sm shadow-pink">
              + File a Case
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((c, i) => {
              const cfg = STATUS_CONFIG[c.status] ?? STATUS_CONFIG.draft
              return (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-white rounded-2xl p-5 shadow-card border border-gray-100 hover:border-pink/30 hover:shadow-pink transition-all cursor-pointer group"
                >
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${cfg.bg} ${cfg.color}`}>
                          {cfg.icon} {cfg.label}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">{c.case_ref}</span>
                      </div>
                      <h3 className="text-dark font-bold mt-2 group-hover:text-pink transition-colors truncate">{c.title}</h3>
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-400 flex-wrap">
                        <span>📂 {c.category}</span>
                        {c.claim_amount && <span>💰 ₹{Number(c.claim_amount).toLocaleString('en-IN')}</span>}
                        <span>📅 {new Date(c.created_at).toLocaleDateString('en-IN')}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {c.status === 'hearing' && (
                        <Link
                          href={`/hearing/${c.id}`}
                          className="flex items-center gap-1.5 bg-pink text-white text-xs font-bold px-4 py-2 rounded-full shadow-pink hover:shadow-pink-lg transition-all"
                          onClick={e => e.stopPropagation()}
                        >
                          <Video size={12} /> Join Hearing
                        </Link>
                      )}
                      <Link
                        href={`/dashboard/${c.id}`}
                        className="text-gray-300 hover:text-pink transition-colors"
                        onClick={e => e.stopPropagation()}
                      >
                        <BarChart3 size={18} />
                      </Link>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}
