-- ─────────────────────────────────────────────────────────────────────────────
-- ODRkart Database Schema  (Supabase / PostgreSQL)
-- Run: supabase db push  OR paste into Supabase SQL Editor
-- ─────────────────────────────────────────────────────────────────────────────

-- Enable pgcrypto for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── USERS (extends Supabase auth.users) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name     TEXT,
  phone         TEXT,
  account_type  TEXT CHECK (account_type IN ('individual','business','law_firm','arbitrator')) DEFAULT 'individual',
  avatar_url    TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── CASES ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.cases (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_ref        TEXT UNIQUE NOT NULL,  -- e.g. ODR-2026-4821
  title           TEXT NOT NULL,
  category        TEXT NOT NULL,
  claim_amount    NUMERIC(15,2),
  resolution_type TEXT CHECK (resolution_type IN ('mediation','arbitration','conciliation','unsure')),
  description     TEXT,
  status          TEXT CHECK (status IN ('draft','filed','review','assigned','hearing','resolved','closed')) DEFAULT 'draft',
  claimant_id     UUID REFERENCES public.profiles(id),
  respondent_name TEXT,
  respondent_email TEXT,
  panelist_id     UUID REFERENCES public.profiles(id),
  ai_report_url   TEXT,  -- S3 key for combined AI report PDF
  payment_intent  TEXT,  -- Stripe PaymentIntent ID
  paid_at         TIMESTAMPTZ,
  filed_at        TIMESTAMPTZ,
  resolved_at     TIMESTAMPTZ,
  hearing_preference TEXT DEFAULT 'video',
  language_preference TEXT DEFAULT 'english',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── CASE DOCUMENTS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.case_documents (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id     UUID REFERENCES public.cases(id) ON DELETE CASCADE,
  uploader_id UUID REFERENCES public.profiles(id),
  file_name   TEXT NOT NULL,
  s3_key      TEXT NOT NULL UNIQUE,
  file_size   BIGINT,
  mime_type   TEXT,
  doc_type    TEXT CHECK (doc_type IN ('evidence','contract','agreement','invoice','other')) DEFAULT 'evidence',
  uploaded_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── AI ANALYSIS REPORTS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.ai_reports (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         UUID REFERENCES public.cases(id) ON DELETE CASCADE UNIQUE,
  company_report  TEXT,   -- full text of internal report
  client_report   TEXT,   -- full text of client summary
  legal_merit     SMALLINT CHECK (legal_merit BETWEEN 0 AND 100),
  risk_level      TEXT CHECK (risk_level IN ('low','medium','high')),
  generated_at    TIMESTAMPTZ DEFAULT NOW(),
  model_used      TEXT DEFAULT 'claude-sonnet-4-20250514'
);

-- ── VIDEO HEARINGS ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.hearings (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id     UUID REFERENCES public.cases(id) ON DELETE CASCADE,
  channel_name TEXT NOT NULL,  -- Agora channel
  scheduled_at TIMESTAMPTZ,
  started_at   TIMESTAMPTZ,
  ended_at     TIMESTAMPTZ,
  recording_url TEXT,  -- S3 key for recording
  status      TEXT CHECK (status IN ('scheduled','live','completed','cancelled')) DEFAULT 'scheduled',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── BLOG POSTS (AI Lab) ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.blog_posts (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title       TEXT NOT NULL,
  excerpt     TEXT,
  content     TEXT,
  category    TEXT,
  emoji       TEXT,
  author      TEXT DEFAULT 'ODRkart AI Lab',
  read_time   TEXT,
  topic_tag   TEXT,
  published   BOOLEAN DEFAULT TRUE,
  published_at TIMESTAMPTZ DEFAULT NOW(),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── PANELISTS ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.panelists (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id    UUID REFERENCES public.profiles(id),
  name          TEXT NOT NULL,
  role          TEXT,
  specializations TEXT[],
  experience_years SMALLINT,
  cases_count   INT DEFAULT 0,
  rating        NUMERIC(3,2) DEFAULT 5.00,
  photo_url     TEXT,
  bio           TEXT,
  available     BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────────────────────
ALTER TABLE public.profiles     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cases        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.case_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_reports   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hearings     ENABLE ROW LEVEL SECURITY;

-- Users can read/write their own profile
CREATE POLICY "profiles: own read"  ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles: own write" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Claimants can see their own cases; panelists can see assigned cases
CREATE POLICY "cases: claimant"  ON public.cases FOR SELECT USING (claimant_id = auth.uid());
CREATE POLICY "cases: panelist"  ON public.cases FOR SELECT USING (panelist_id = auth.uid());
CREATE POLICY "cases: insert"    ON public.cases FOR INSERT WITH CHECK (claimant_id = auth.uid());
CREATE POLICY "cases: update own" ON public.cases FOR UPDATE USING (claimant_id = auth.uid() AND status = 'draft');

-- Documents follow case access
CREATE POLICY "docs: case access" ON public.case_documents FOR SELECT
  USING (case_id IN (SELECT id FROM public.cases WHERE claimant_id = auth.uid() OR panelist_id = auth.uid()));

-- Hearings follow case access
CREATE POLICY "hearings: case access" ON public.hearings FOR SELECT
  USING (case_id IN (SELECT id FROM public.cases WHERE claimant_id = auth.uid() OR panelist_id = auth.uid()));

-- Service role bypasses RLS (for API routes)
-- (Handled automatically by Supabase service role key)

-- ── FUNCTIONS ─────────────────────────────────────────────────────────────────
-- Auto-generate case_ref on insert
CREATE OR REPLACE FUNCTION generate_case_ref()
RETURNS TRIGGER AS $$
BEGIN
  NEW.case_ref := 'ODR-' || EXTRACT(YEAR FROM NOW()) || '-' || LPAD(FLOOR(RANDOM() * 9000 + 1000)::TEXT, 4, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_case_ref BEFORE INSERT ON public.cases
  FOR EACH ROW WHEN (NEW.case_ref IS NULL) EXECUTE FUNCTION generate_case_ref();

-- Auto update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER cases_updated   BEFORE UPDATE ON public.cases   FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── INDEXES ───────────────────────────────────────────────────────────────────
CREATE INDEX idx_cases_claimant ON public.cases(claimant_id);
CREATE INDEX idx_cases_status   ON public.cases(status);
CREATE INDEX idx_cases_ref      ON public.cases(case_ref);
CREATE INDEX idx_docs_case      ON public.case_documents(case_id);
CREATE INDEX idx_blog_category  ON public.blog_posts(category);
