// store/caseStore.ts
// Zustand store managing multi-step case filing wizard state.
// Persists to sessionStorage so refresh doesn't lose progress.

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'

// ── Step data types ───────────────────────────────────────────────────────────
export interface StepOneData {
  title:          string
  category:       string
  claimAmount:    string
  resolutionType: 'mediation' | 'arbitration' | 'conciliation' | 'unsure' | ''
  description:    string
}

export interface StepTwoData {
  claimantName:    string
  claimantEmail:   string
  respondentName:  string
  respondentEmail: string
}

export interface UploadedFile {
  id:       string
  name:     string
  size:     number
  mimeType: string
  s3Key:    string
  docId:    string
  progress: number
  status:   'uploading' | 'done' | 'error'
}

export interface AIReportData {
  companyReport:  string
  clientReport:   string
  legalMerit:     number
  riskLevel:      'low' | 'medium' | 'high'
  generatedAt:    string
}

export interface StepFiveData {
  desiredOutcome:     string
  hearingPreference:  'video' | 'async' | 'in_person'
  languagePreference: string
}

export interface CaseStore {
  // Navigation
  currentStep:  number
  caseId:       string | null       // UUID from DB after creation
  caseRef:      string | null       // e.g. ODR-2026-4821
  paymentIntentId: string | null

  // Step data
  step1: StepOneData
  step2: StepTwoData
  files: UploadedFile[]
  aiReport: AIReportData | null
  step5: StepFiveData

  // Actions
  setStep:            (step: number) => void
  setStep1:           (data: Partial<StepOneData>) => void
  setStep2:           (data: Partial<StepTwoData>) => void
  addFile:            (file: UploadedFile) => void
  updateFileProgress: (id: string, progress: number, status?: UploadedFile['status'], s3Key?: string, docId?: string) => void
  removeFile:         (id: string) => void
  setAIReport:        (report: AIReportData) => void
  setStep5:           (data: Partial<StepFiveData>) => void
  setCaseId:          (id: string, ref: string) => void
  setPaymentIntent:   (id: string) => void
  resetStore:         () => void
}

const defaultStep1: StepOneData = {
  title: '', category: '', claimAmount: '',
  resolutionType: '', description: '',
}
const defaultStep2: StepTwoData = {
  claimantName: '', claimantEmail: '',
  respondentName: '', respondentEmail: '',
}
const defaultStep5: StepFiveData = {
  desiredOutcome: 'Full monetary compensation',
  hearingPreference: 'video',
  languagePreference: 'english',
}

export const useCaseStore = create<CaseStore>()(
  persist(
    (set) => ({
      currentStep:     0,
      caseId:          null,
      caseRef:         null,
      paymentIntentId: null,
      step1:           { ...defaultStep1 },
      step2:           { ...defaultStep2 },
      files:           [],
      aiReport:        null,
      step5:           { ...defaultStep5 },

      setStep:   (step)              => set({ currentStep: step }),
      setStep1:  (data)              => set(s => ({ step1: { ...s.step1, ...data } })),
      setStep2:  (data)              => set(s => ({ step2: { ...s.step2, ...data } })),
      addFile:   (file)              => set(s => ({ files: [...s.files, file] })),
      updateFileProgress: (id, progress, status, s3Key, docId) =>
        set(s => ({
          files: s.files.map(f =>
            f.id === id ? { ...f, progress, ...(status && { status }), ...(s3Key && { s3Key }), ...(docId && { docId }) } : f
          ),
        })),
      removeFile:      (id)          => set(s => ({ files: s.files.filter(f => f.id !== id) })),
      setAIReport:     (report)      => set({ aiReport: report }),
      setStep5:        (data)        => set(s => ({ step5: { ...s.step5, ...data } })),
      setCaseId:       (id, ref)     => set({ caseId: id, caseRef: ref }),
      setPaymentIntent:(id)          => set({ paymentIntentId: id }),
      resetStore:      ()            => set({
        currentStep: 0, caseId: null, caseRef: null, paymentIntentId: null,
        step1: { ...defaultStep1 }, step2: { ...defaultStep2 },
        files: [], aiReport: null, step5: { ...defaultStep5 },
      }),
    }),
    {
      name: 'odrkart-case-draft',
      storage: createJSONStorage(() => sessionStorage),
      partialize: (state) => ({
        currentStep: state.currentStep,
        step1: state.step1,
        step2: state.step2,
        step5: state.step5,
        caseId: state.caseId,
        caseRef: state.caseRef,
      }),
    }
  )
)
