// types/database.ts
// Generated type definitions matching the Supabase PostgreSQL schema.
// Kept hand-maintained here; can also be auto-generated via: supabase gen types typescript

export type Json = string | number | boolean | null | { [key: string]: Json } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id:           string
          full_name:    string | null
          phone:        string | null
          account_type: 'individual' | 'business' | 'law_firm' | 'arbitrator' | null
          avatar_url:   string | null
          created_at:   string
          updated_at:   string
        }
        Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>
      }
      cases: {
        Row: {
          id:                  string
          case_ref:            string
          title:               string
          category:            string
          claim_amount:        number | null
          resolution_type:     'mediation' | 'arbitration' | 'conciliation' | 'unsure' | null
          description:         string | null
          status:              'draft' | 'filed' | 'review' | 'assigned' | 'hearing' | 'resolved' | 'closed'
          claimant_id:         string | null
          respondent_name:     string | null
          respondent_email:    string | null
          panelist_id:         string | null
          ai_report_url:       string | null
          payment_intent:      string | null
          paid_at:             string | null
          filed_at:            string | null
          resolved_at:         string | null
          hearing_preference:  string | null
          language_preference: string | null
          created_at:          string
          updated_at:          string
        }
        Insert: Omit<Database['public']['Tables']['cases']['Row'], 'id' | 'case_ref' | 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['cases']['Insert']>
      }
      case_documents: {
        Row: {
          id:          string
          case_id:     string
          uploader_id: string | null
          file_name:   string
          s3_key:      string
          file_size:   number | null
          mime_type:   string | null
          doc_type:    'evidence' | 'contract' | 'agreement' | 'invoice' | 'other'
          uploaded_at: string
        }
        Insert: Omit<Database['public']['Tables']['case_documents']['Row'], 'id' | 'uploaded_at'>
        Update: Partial<Database['public']['Tables']['case_documents']['Insert']>
      }
      ai_reports: {
        Row: {
          id:              string
          case_id:         string
          company_report:  string | null
          client_report:   string | null
          legal_merit:     number | null
          risk_level:      'low' | 'medium' | 'high' | null
          generated_at:    string
          model_used:      string | null
        }
        Insert: Omit<Database['public']['Tables']['ai_reports']['Row'], 'id' | 'generated_at'>
        Update: Partial<Database['public']['Tables']['ai_reports']['Insert']>
      }
      hearings: {
        Row: {
          id:            string
          case_id:       string
          channel_name:  string
          scheduled_at:  string | null
          started_at:    string | null
          ended_at:      string | null
          recording_url: string | null
          status:        'scheduled' | 'live' | 'completed' | 'cancelled'
          created_at:    string
        }
        Insert: Omit<Database['public']['Tables']['hearings']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['hearings']['Insert']>
      }
      blog_posts: {
        Row: {
          id:           string
          title:        string
          excerpt:      string | null
          content:      string | null
          category:     string | null
          emoji:        string | null
          author:       string | null
          read_time:    string | null
          topic_tag:    string | null
          published:    boolean
          published_at: string
          created_at:   string
        }
        Insert: Omit<Database['public']['Tables']['blog_posts']['Row'], 'id' | 'published_at' | 'created_at'>
        Update: Partial<Database['public']['Tables']['blog_posts']['Insert']>
      }
      panelists: {
        Row: {
          id:                string
          profile_id:        string | null
          name:              string
          role:              string | null
          specializations:   string[] | null
          experience_years:  number | null
          cases_count:       number
          rating:            number
          photo_url:         string | null
          bio:               string | null
          available:         boolean
          created_at:        string
        }
        Insert: Omit<Database['public']['Tables']['panelists']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['panelists']['Insert']>
      }
    }
    Views: {}
    Functions: {}
    Enums: {}
  }
}

// ── Convenience type aliases ──────────────────────────────────────────────────
export type Profile       = Database['public']['Tables']['profiles']['Row']
export type Case          = Database['public']['Tables']['cases']['Row']
export type CaseDocument  = Database['public']['Tables']['case_documents']['Row']
export type AIReport      = Database['public']['Tables']['ai_reports']['Row']
export type Hearing       = Database['public']['Tables']['hearings']['Row']
export type BlogPost      = Database['public']['Tables']['blog_posts']['Row']
export type Panelist      = Database['public']['Tables']['panelists']['Row']
