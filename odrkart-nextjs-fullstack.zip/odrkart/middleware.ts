// middleware.ts
// Auth middleware using Supabase. Runs at the edge (Cloudflare / Vercel Edge Network).
// Protects /dashboard, /file, /hearing, and all API routes.

import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs'
import { NextRequest, NextResponse } from 'next/server'

const PROTECTED_PATHS = ['/dashboard', '/file', '/hearing', '/api/cases', '/api/upload', '/api/video']

export async function middleware(req: NextRequest) {
  const res  = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  // Refresh the session cookie automatically
  const { data: { session } } = await supabase.auth.getSession()

  const { pathname } = req.nextUrl

  // API routes → 401 JSON response
  if (pathname.startsWith('/api/') && PROTECTED_PATHS.some(p => pathname.startsWith(p))) {
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // Page routes → redirect to login with ?next= param
  if (!pathname.startsWith('/api/') && PROTECTED_PATHS.some(p => pathname.startsWith(p))) {
    if (!session) {
      const url = req.nextUrl.clone()
      url.pathname = '/login'
      url.searchParams.set('next', pathname)
      return NextResponse.redirect(url)
    }
  }

  return res
}

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/file/:path*',
    '/hearing/:path*',
    '/api/cases/:path*',
    '/api/upload/:path*',
    '/api/video/:path*',
    '/api/ai/analyse/:path*',  // AI analysis requires auth
  ],
}
